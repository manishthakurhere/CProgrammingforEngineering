package com.example.ssbcrackpractice;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class fourth_day extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fourth_day);


        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("GTO");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
    public void gto_one_ago(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_one_a.class);
        startActivity(intent);
    }
    public void gto_one_bgo(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_one_b.class);
        startActivity(intent);
    }
    public void gto_two_ago(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_two_a.class);
        startActivity(intent);
    }
    public void gto_two_bgo(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_two_b.class);
        startActivity(intent);
    }
    public void gto_three_ago(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_three_a.class);
        startActivity(intent);
    }
    public void gto_three_bgo(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_three_b.class);
        startActivity(intent);
    }
    public void gto_four_ago(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_four_a.class);
        startActivity(intent);
    }
    public void gto_four_bgo(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_four_b.class);
        startActivity(intent);
    }
    public void gto_five_ago(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_five_a.class);
        startActivity(intent);
    }
    public void gto_five_bgo(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_five_b.class);
        startActivity(intent);
    }
    public void gto_six_ago(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_six_a.class);
        startActivity(intent);
    }
    public void gto_six_bgo(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_six_b.class);
        startActivity(intent);
    }
    public void gto_seven_ago(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_seven_a.class);
        startActivity(intent);
    }
    public void gto_seven_bgo(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_seven_b.class);
        startActivity(intent);
    }
    public void gto_eight_ago(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_eight_a.class);
        startActivity(intent);
    }
    public void gto_eight_bgo(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_eight_b.class);
        startActivity(intent);
    }
    public void gto_nine_ago(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_nine_a.class);
        startActivity(intent);
    }
    public void gto_nine_bgo(View view)
    {
        Intent intent=new Intent(fourth_day.this,gto_nine_b.class);
        startActivity(intent);
    }

}
