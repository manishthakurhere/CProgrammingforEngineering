package com.example.ssbcrackpractice;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class srt_three extends AppCompatActivity {
    int count=0;
    String words[]={"sample","You are studying for your 12th standard boards exams and tsunami smashed your coastal town. You will... ","He is the newly appointed captain after finishing his engineering in electronics for a small ship and on the trail he lose his communication with the coast and its about to lose whole steadiness because of failure of communication device. You will…"," While going for a symposium in City College, you see your group is losing ground on a friendly talk, you will...","While going for a symposium in City College, you see your opposite group of persons involving in a serious discussion and it heats up with your group. You will...","He has to go to final round of interview and the whole city is shutdown without transportation as a big leader dies. you will..."," A new family settled in your neighbor flat imports smuggled goods, and your wife wants to purchase it for your house at cheaper rate. You will...","Your team leader corners you many times before your group and while lunch time discussion, everyone talks badly about team leader in his absence by supporting you. You will..","Only three days are there for final submission of project, but the team mate who knows most of the modules left the team in some issue. You will...","You are the class representative and in free hours you are calling Engineering mathematics professor more to take class by knowing this, physics professor gets anger and corners you to fail in the lab practical. You will...","His mother dies due to cancer at early age and his father left him with second marriage, You will...","You are requested to organize a cycling trip, you will...","While going on a cycle trip, your cycle got punctured and no one in that place and it is getting dark, you will...","Your long back friend asks you some money which you have, but you already know that he has the habit of drinking. You will...","Due to metro rail works, you find your normal way of traffic is blocked and its getting late for meeting and members waiting at meeting hall are yelling at you, You will..","You get less score in 12th standard and because of this, you get seat in rural college andas you were from city boys are not friendly with you. You will...","You are about to start to office and your mother faints in kitchen, you are asking leave to boss which he neglects the appeal. You will...","You are in urgent need of birth certificate at taluk office but the clerk asks you some bribe for urgent delivery, You will...","Because of strenuous training for competition, he got severe muscle cramp before the match day, He will...","After your graduation you get high paid job at the same time you get seat for master degree at Government College. You will...","Your son wants to study in international residential school, but you want to join him cynic school. You will...","You are in love with a girl; your aim in life is to become an Army officer, while she wants to see you as software professional. You will...","Before the exam, you are teaching your friend to get pass in exam, but on the examination hall he is copying from a book. You will...","You are taking your girl friend to nearby mountain forest for trekking, its late in the evening you both lost your way and she is feeling faint as both were fully tired. You will....","On the journey to forest trip in week end, your friend insists you to aim and shoot a spotted deer. You will...","Day are near to board exam, but he couldn’t able to improve his score in mathematics. He will...","He is interested to study science stream in junior college, but his father insists him to study mathematics. He will...","You are buying medicine to your mother at late night and on the way you saw a person seriously injured and hit by a robber group on the way. You will...","On the arrival to SSB, you find the candidate line is not clean and comfortable to stay. You will...","Your family members have planned to murder your maternal uncle for property cases. You will...","Your father was accused for murdering your maternal uncle and you were the only eye witness. You will...","You and your friends going boating in river ganga and suddenly you noticed water gushing in the floor of boat. You will...","You and your friends on boating and suddenly, boat started to mishap and you are the only person to know swimming and other two dont know. You will...","During the SSB stay, 4 days crossed and next day is conference and he was very sure about getting recommended. Suddenly he got a phone call about his grand father’s demise. He will...","While waiting at the MCO, he was about to leave to the SSB bus and noticed that his bag was missing. He will...","He was about to land at Allahabad station for SSB and noticed that the bag was missing. He will...","His parents left you and your younger sister at home and you are preparing for your practicals, suddenly your sister was suffering from epilepsy. You will...","He was organizing a cricket match and the day before night it started heavily raining and ground was full of water. As we were responsible, he will....","You advice your friend to study regularly, but before the day of exam he is coming to you wit loads of doubts and you were on your serious revision. You will...","You are asking a double to your professor at class and he discourages you before all. You will...","During the final round of project submission, his leader got a call about his fathers heart attack. You are requested to make the project demo to client... You will","While evening study, guests arrived at home and his mother orders to buy some snacks, on the way back it started raining heavily and water flooded the streets and guests are waiting in home, he will....","After the September passing out parade from OTA Chennai, you are requested to report at Kashmir in December where your father has heart operation on the same reporting day, you will...","After reporting to your Commanding Officer you come to know that he is tough to talk, you feel so many things to change in the unit and you will...","Your Commanding Officer never gives your permission to implement your ideas, but on the winter morning, your bunker gets heavy shelling from western side, you will...","You are a south Indian and you don’t know Hindi well, while going to SSB at Allahabad, you lost your purse in train, you will...","You are a fresh graduate of MBA taking in charge of your fathers business and after your leading there is a sudden fall in business profits and you will...","You are owning a business and you have good amount of money, your brother scored less marks in board exam while your brothers friend scored good marks in exam and he don’t have enough money to pursue engineering. Your brother also wants to pursue the same, you will....","You are in charge to release salary for your unit as they are going to home for diwali leave. On the way the village is with several riots and you can’t move the vehicle in roads also chances for looting the money if you choose alternate short cuts, you will....","While travelling in train you are playing with a kid, suddenly the gold chain of the baby missing and their parents doubting you. you will...","While travelling in train, you see group of saniyasis taking Ganja near the washbasin and it causes severe breath trouble to passengers, you will....","You are taking your sister from your village to nearby town for her regular check up as she is pregnant. Suddenly, while crossing a jungle area, you see a person snatching a lady chain and run away from train. You will....","On the journey to college for your final year engineering project review, you got a call from your project co-coordinator son as he met with an accident and struggling in ICU, you will...","You got in Mumbai express from Chennai central at platform no. 1 where you want to go to Hyderabad express which usually stands at platform no. 1. The train started and you come to know that when ticket examiner asks you the ticket. You will....","You are in serious love with a girl and while you return late from 2nd show of film, you saw her with your neighbor. you will...","You are going to get a train by 10.30 am, its already 10 am. The usual journey time is half an hour. On the way you saw person getting beated by group of bad elements. You will...","You are going to get a train by 10.30 am, its already 10 am. The usual journey time is half an hour. On the way you saw old lady getting fainted in the road while crossing it. You will...","Your brother who got selected for the state level table tennis tournament left the home to railway station without the bat. You notice and rushing to the railway station without taking the original license and traffic police makes you to wait and enquire, you will.....","Your coach asks you to organize the table tennis tournament, you will...","You are in love with a girl while studying engineering and you both study well to get good job with good salary, later you came to know that her father was responsible to make your father business let down and you will...."};
    String number[]={"sample","2/60","3/60","4/60","5/60","6/60","7/60","8/60","9/60","10/60","11/60","12/60","13/60","14/60","15/60","16/60","17/60","18/60","19/60","20/60","21/60","22/60","23/60","24/60","25/60","26/60","27/60","28/60","29/60","30/60","31/60","32/60","33/60","34/60","35/60","36/60","37/60","38/60","39/60","40/60","41/60","42/60","43/60","44/60","45/60","46/60","47/60","48/60","49/60","50/60","51/60","52/60","53/60","54/60","55/60","56/60","57/60","58/60","59/60","60/60"};

    Timer t = new Timer();
    public MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_srt_three);
        mp = MediaPlayer.create(this, R.raw.camera);

        t.scheduleAtFixedRate(
                new TimerTask() {
                    @Override
                    public void run() {


                        mp.start();


                    }
                }, 0,
                30000);

        final TextView textView=(TextView)findViewById(R.id.textid);
        final TextView textView1=(TextView)findViewById(R.id.srtno);

        Thread t=new Thread(){



            @Override
            public void run(){


                while(!isInterrupted()){

                    try {
                        Thread.sleep(30000);  //1000ms = 1 sec

                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                count++;
                                if (count < words.length){

                                    textView.setText(words[count]);
                                    textView1.setText(number[count]);

                                }else{
                                    srt_three.this.finish();
                                }
                            }
                        });

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        };

        t.start();

        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("SRT-3");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
    @Override
    protected void onPause() {
        t.cancel();
        super.onPause();
    }
}
