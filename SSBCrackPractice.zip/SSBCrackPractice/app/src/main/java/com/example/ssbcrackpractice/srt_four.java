package com.example.ssbcrackpractice;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class srt_four extends AppCompatActivity {
    int count=0;
    String words[]={"sample","You lost your communication device and you saw few persons are crossing the border. As a newly posted lieutenant what will you do... ","On walking on a lonely road from railway station to home, a person snatches the gold chain of your mother and sprinkle chilly powder over your face and start to run. you will..."," You have promised your girl friend to give a dinner party at friday night at the same time, your boss has invited you for team informal dinner. You will...","You are interested to pursue mechanical engineering but your father insisted you and joined in computer science. Later you feel so hard to pursue it because of lack of interest. You will...","You take a boy to pond to teach him swimming but suddenly that boy suffered from breathing problem, you will..."," You are ordered by principal to organize the college election in straight forward manner, but the local group threatens you to give their candidature with more advantage. You will...","After the heavy storm, your town has fully lost its transportation and no food supplies was there. You will...","While returning from second show of cinema, the police man doubted you for murder and accusing you with false witness. You will...","You are a new trainee software engineer and you are given too much unrelated work from your from boss. You will...","You have started late to the railway station and insisting the auto driver to drive fast. Because of this the auto collides with a vehicle coming on the way. You will...","You are an young army officer and returning home after the service for leave and you see the local police is doing so many illegal activities. you will...","You are asked to organize a blood donation camp, you will...","You are waiting for your friend to pick you at railway station, while on the platform you see a old beggar shivering in dead cold. You too don’t have anything to give but you are ok with cold due to your young age. You will...","Your uncle bough all your property illegally and your father is working hard to support your family but he couldn’t, as a responsible son what you will do...","You are on library taking notes for your seminar, but your seniors are making sounds and disturbing the environment, you will...","While travelling in metro train, you saw a man acting as blind and getting money from all. You will...","While travelling in metro train, you saw a boy pick pocketing money from a person at rush. You will...","In the absence of your boss, you are assigned a job which you don’t know at even 1 %, but you are pushed to finish the same in time. You will...","You are going to a friend’s reception by wearing new dress in bike, while near to the reception hall in a road signal, a person spits you pan from the bus. You will....","While taking your new bike, you felt that brake is not working when going in very high speed, you will...","In a birthday party, your friend hits you and you know that he is drunk. You will...","You feel yourself legal and because of this you find your view and opinion is not accepted by others or at work, you will...","You got high package job at foreign country which is a one time opportunity, but your sick mother wants to be here and do a local job. You will...","You are in charge to board your old grandfather to Chennai. While settling down and before few minutes to start the train, you notice that boarded on Madurai express instead of Chennai express. you will...","You are a newly posted lieutenant, and it’s an emergency but your seniors are giving a wrong orders and implementing it may lead to lose of your team members life. You will...","You are organizing a football tournament and in that two local teams with a history of rivalry, plans to fight with each other. You will...","You are going to Darjeeling, where your family mates want to take a photograph in lawn where entry is prohibited. But they are looking sad because of that denial. You will...","While on trekking in a NCC Camp, your leader got severe angle bone injury which made him not to move a single step, you will....","He worked hard throughout the year and he got a very little appraisal, he will...","At the evening discussion with his friends, he plans to do start something new, he will...","He is working in a two member team, at the time of promotion his colleague got more credits even though he worked well, he will...","You are on your morning jogging, on the way you saw a old man cleaning his buffalo in river, got struggling along With buffalo to come out of heavy water current. You don’t know swimming, you will....","His neighbor scolded his mother badly, when he arrives home late from officer, he will...","Boys playing cricket near his home, started teasing his mother, he will...","The thing which makes you happy is....","The thing which makes you sad is...","The boss goes for foreign trip and he will return after 3 months, in this duration what you will do develop the company...","An orphanage approaches him for help to collect the money for the needy people, he will...","As a member of the college sports board, he was in charge of selecting students for team, at that time his professor approach him for selecting his own son into the team, while he handles a subject with practical for him, he will....","You are only one from your department to get selected for college cricket team and while at practice your senior scolds you badly at mistakes. You will...","You were going to the back of your apartment side and saw few people taking liquor. You will....","You asked a person to do plumbing work in your apartment and suddenly the man loses his balance and falls from first floor. He will...","On the week end highway trip, you are running the car at high speed which hits a small child playing near the road. You will...","The meteorological department warns your district that big storm is going to hit, you will....","Your sister is preparing for her exams and light suddenly switch off in your apartment. You will...","On the way to give money for your friend’s father who is at hospital for surgery, you found your bag with money is missing. You will...","When travelling in train, you found some passengers taking liquor in front of all. You will...","You don’t know Hindi, and while going to north India, you notice that people are joking at you in Hindi. You will…","You are involving in hot discussion with your team leader and team leader convinces his point logically to you and he is correct with that. You will...","When having discussion about a national issue, you gave a point which harms a particular group of friends of some other religion, you will...","Your friends calling you for college strike for failing few classmates at lab exam. You will...","In college hostel, the food is not served as per the given schedule. You will...","You and your girl friend is travelling in a private bus and suddenly the driver and his colleagues started to misbehave with your girl friend. You will...","You love your class mate and your friend gives a better gift than you to her. You will...","As a college representative, you are given order to motivate students to attend the University Entry Scheme program for Army, you will...","You are in charge of sentry post and you saw a truck fully loaded with hidden materials speeding towards the forest lane. You will...","You are newly posted lieutenant at the border and communal clash breaks at the village. You will...","When you were enjoying camp fire at NCC camp, you saw forest fire started at the forest. you will...","While watching cinema, the person nearby continuously spitting pan near your legs and front seat. You will..."};
    String number[]={"sample","2/60","3/60","4/60","5/60","6/60","7/60","8/60","9/60","10/60","11/60","12/60","13/60","14/60","15/60","16/60","17/60","18/60","19/60","20/60","21/60","22/60","23/60","24/60","25/60","26/60","27/60","28/60","29/60","30/60","31/60","32/60","33/60","34/60","35/60","36/60","37/60","38/60","39/60","40/60","41/60","42/60","43/60","44/60","45/60","46/60","47/60","48/60","49/60","50/60","51/60","52/60","53/60","54/60","55/60","56/60","57/60","58/60","59/60","60/60"};

    Timer t = new Timer();
    public MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_srt_four);
        mp = MediaPlayer.create(this, R.raw.camera);

        t.scheduleAtFixedRate(
                new TimerTask() {
                    @Override
                    public void run() {


                        mp.start();


                    }
                }, 0,
                30000);

        final TextView textView=(TextView)findViewById(R.id.textid);
        final TextView textView1=(TextView)findViewById(R.id.srtno);

        Thread t=new Thread(){



            @Override
            public void run(){


                while(!isInterrupted()){

                    try {
                        Thread.sleep(30000);  //1000ms = 1 sec

                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                count++;
                                if (count < words.length){

                                    textView.setText(words[count]);
                                    textView1.setText(number[count]);

                                }else{
                                    srt_four.this.finish();
                                }
                            }
                        });

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        };

        t.start();


        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("SRT-4");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
    @Override
    protected void onPause() {
        t.cancel();
        super.onPause();
    }
}
