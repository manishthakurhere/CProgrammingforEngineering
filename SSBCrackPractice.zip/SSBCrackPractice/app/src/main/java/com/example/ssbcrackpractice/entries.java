package com.example.ssbcrackpractice;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class entries extends AppCompatActivity {
    ExpandableListView expandableListView;

    List<String> question;
    Map<String,List<String>> answer;
    ExpandableListAdapter listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entries);

        expandableListView = (ExpandableListView)findViewById(R.id.expandableListView);
        fillData();

        listAdapter=new MyexListadapter(this,question,answer);
        expandableListView.setAdapter(listAdapter);


        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {



                return true;
            }
        });



        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("Entries");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    public void fillData()
    {
        question=new ArrayList<>();
        answer = new HashMap<>();

        question.add("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tJOINING\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tINDIAN\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tARMY\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t(ENTRIES)");
        question.add("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tJOINING\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tINDIAN\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAIR FORCE\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t(ENTRIES)");
        question.add("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tJOINING\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tINDIAN\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tNAVY\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t(ENTRIES)");




        List<String> one = new ArrayList<>();
        List<String> two= new ArrayList<>();
        List<String> three= new ArrayList<>();



        one.add("\n" +
                "1: National Defence Academy (NDA) and Naval Academy (NA): \n" +
                "\tConducted Twice an Year\n" +
                "\tEligibility: Studying/passed 10+2 and Qualified Written exam\n" +
                "\tAge Limit: 16.5 to 19.5 years\n\n" +
                "2: Combined Defence Service Examination (CDSE): \n" +
                "\tConducted Twice an Year\n" +
                "\tEligibility: Graduate/Final Year of Graduation and Qualified Written exam\n" +
                "\tAge Limit: 19 to 24 years(IMA), 25 years for OTA\n\n" +
                "3: 10+2 Technical Entry Scheme (TES): \n" +
                "\tConducted Twice an year\n" +
                "\tEligibility: Qualifed 10+2 and minimum aggregate of 70% marks in Physics, Chemistry and Mathematics\n" +
                "\tAge Limit: 16.5 to 19.5 years\n\n" +
                "4: University Entry Scheme (UES):\n" +
                "\tConducted once an year\n" +
                "\tEligibility: Engineering student in pre-final or third year.\n" +
                "\tAge Limit: 19 to 24 years\n\n" +
                "5: Technical Graduates Course (TGC):\n" +
                "\tConducted Twice an year\n" +
                "\tEligibility: Engineering graduates from notified Branch.\n" +
                "\tAge Limit:20 to 27 years \n\n" +
                "6: Short Service Commission (Technical) Entry:\n" +
                "\tConducted twice an year\n" +
                "\tEligibility: Engineering graduates from notified Branch.\n" +
                "\tAge Limit: 20 to 27 years\n\n" +
                "7: NCC (Special Entry Scheme):\n" +
                "\tConducted Twice an year\n" +
                "\tEligibility:University graduates possessing NCC ‘C’ Certificate with minimum ‘B’ grade and 50% aggregate marks in graduation examination.\n" +
                "\tAge Limit: 19 to 25 years\n\n" +
                "8: Judge Advocate General Entry:\n" +
                "\tConducted one an year.\n" +
                "\tEligibility: Candidates who have scored 55 percent and above in Law college.\n" +
                "\tAge Limit: 21 to 27 years\n\n" +
                "9: Short Service Commission Women:\n" +
                "\tEligibility: Engineering graduates from notified Branch.\n" +
                "\tAge Limit: 20 to 27 years\n\n" +
                "10: Army Cadet College (ACC) Entry:\n" +
                "\tEligibility: 10+2 qualified and Minimum 2 year service in Army/Air Force/Navy and qualified written test.\n" +
                "\tAge Limit: 20 to 27 years\n\n" +
                "11: Special Commissioned Officers (SCO) Scheme: \n" +
                "\tEligibility: 10+2 qualified\n" +
                "\tAge Limit: 28 to 35 years\n\n" +
                "12: Permanent Commission (Special List) (PC SL):\n" +
                "\tEligibility: Minimum 10 years of service and 10+2 qualified.\n" +
                "\tAge Limit: upto 42 years\n\n" +
                "13: Territorial Army:\n" +
                "\tEligibility: Male candidates and graduate from recognized university.\n" +
                "\tAge Limit: 18 to 42 years ");

        two.add("\n" +
                "1: National Defence Academy (NDA) and Naval Academy (NA): \n" +
                "\tConducted Twice an Year\n" +
                "\tEligibility: Studying/passed 10+2 and Qualified Written exam\n" +
                "\tAge Limit: 16.5 to 19.5 years\n\n" +
                "2: Combined Defence Service Examination (CDSE): \n" +
                "\tConducted Twice an Year\n" +
                "\tEligibility: Graduate/Final Year of Graduation and Qualified Written exam\n" +
                "\tAge Limit: 19 to 24 years(IMA), 25 years for OTA\n\n" +
                "3: AFCAT (Air Force Common Admission Test)\n" +
                "\tConducted twice an Year\n" +
                "\tEligibility:  Graduation (min 3 years) in any discipline with min 60% marks and have passed Maths and Physics as subject at 10+2 level B.E/ B.Tech from a recognized University with min 60% marks.\n" +
                "\tAge Limit: 20 to 24 years(Flying), 20 to 26 (Others)\n\n" +
                "4: NCC Special Entry: \n" +
                "\tEligibility: Air Wing Senior Division ’C’ Certificate holder\n" +
                "\tAge Limit: 20 to 24 years");


        three.add("\n" +
                "1: National Defence Academy (NDA) and Naval Academy (NA): \n" +
                "\tConducted Twice an Year\n" +
                "\tEligibility: Studying/passed 10+2 and Qualified Written exam\n" +
                "\tAge Limit: 16.5 to 19.5 years\n\n" +
                "2: 10+2 (Cadet Entry Scheme):\n" +
                "\tConducted Twice an year\n" +
                "\tEligibility: Passed 10+2 with at least 70% aggregate marks in PCM and at least 50% marks in English (either in Class X or Class XII).\n" +
                "\tAge Limit: 16.5 to 19.5 years.\n\n" +
                "3: University Entry Scheme (UES):\n" +
                "\tConducted once an year\n" +
                "\tEligibility: Engineering student in pre-final or third year.\n" +
                "\tAge Limit: 19 to 24 years\n\n" +
                "4: NCC Special Entry: \n" +
                "\tEligibility:  NCC ‘C’ certificate with minimum ‘B’ grading and 50% marks in the graduation.\n" +
                "\tAge Limit: 19 to 25 years.\n" +
                "\t\n" +
                "\t");








        answer.put(question.get(0),one);
        answer.put(question.get(1),two);
        answer.put(question.get(2),three);






    }

}
