package com.example.ssbcrackpractice;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class first_day extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_day);


        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("SCREENING");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    public void gotoppdtone(View view)
    {
        Intent intent=new Intent(first_day.this,ppdtone.class);
        startActivity(intent);
    }
    public void gotoppdttwo(View view)
    {
        Intent intent=new Intent(first_day.this,ppdttwo.class);
        startActivity(intent);
    }
    public void gotoppdtthree(View view)
    {
        Intent intent=new Intent(first_day.this,ppdtthree.class);
        startActivity(intent);
    }
    public void gotoppdtfour(View view)
    {
        Intent intent=new Intent(first_day.this,ppdtfour.class);
        startActivity(intent);
    }
    public void gotoppdtfive(View view)
    {
        Intent intent=new Intent(first_day.this,ppdtfive.class);
        startActivity(intent);
    }
    public void gotoppdtsix(View view)
    {
        Intent intent=new Intent(first_day.this,ppdtsix.class);
        startActivity(intent);
    }
    public void gotoppdtseven(View view)
    {
        Intent intent=new Intent(first_day.this,ppdtseven.class);
        startActivity(intent);
    }
    public void gotoppdteight(View view)
    {
        Intent intent=new Intent(first_day.this,ppdteight.class);
        startActivity(intent);
    }
    public void gotoppdtnine(View view)
    {
        Intent intent=new Intent(first_day.this,ppdtnine.class);
        startActivity(intent);
    }
    public void gotoppdtten(View view)
    {
        Intent intent=new Intent(first_day.this,ppdtten.class);
        startActivity(intent);
    }


    public void gotooirone(View view)
    {
        Intent intent=new Intent(first_day.this,oir_one.class);
        startActivity(intent);
    }
    public void gotooirtwo(View view)
    {
        Intent intent=new Intent(first_day.this,oir_two.class);
        startActivity(intent);
    }
    public void gotooirthree(View view)
    {
        Intent intent=new Intent(first_day.this,oir_three.class);
        startActivity(intent);
    }
    public void gotooirfour(View view)
    {
        Intent intent=new Intent(first_day.this,oir_four.class);
        startActivity(intent);
    }
    public void gotooirfive(View view)
    {
        Intent intent=new Intent(first_day.this,oir_five.class);
        startActivity(intent);
    }

}
