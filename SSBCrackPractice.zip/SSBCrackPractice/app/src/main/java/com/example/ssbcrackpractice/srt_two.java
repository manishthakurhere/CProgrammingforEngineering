package com.example.ssbcrackpractice;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class srt_two extends AppCompatActivity {
    int count=0;
    String words[]={"sample"," His colleagues advised him to be tactful with his boss. He..  ","He had already decided to vote for a particular candidate whereas his friends wanted his commitment for the other candidate. He.. ","  When he observed that his friend was having some suspicion on him. He.. ",". At the time of interview, he found that his certificates were missing. He.. ","His parents often irritated him with their orthodox ideas about the role of women in a society. He.. "," After marriage, his in-laws forced him to leave the job. He.. ","3. He was captain of basketball team and his team was about to loose in the final. He.. ","  He had to appear in an exam. On reaching the city, he noticed that curfew had been clamped. He.. "," While passing through a mountainous track he was challenged by two persons with weapons in their hands. He.. "," His father had borrowed some money for his higher studies which he could not pay back. So He.."," While he was watching cinema he suddenly noticed smoke coming out of cinema hall. The viewers started running causing stampede. He.."," Recently his younger brother had become arrogant. So He.."," He entered the bathroom and notices a black cobra hanging from the ceiling of the roof. He.. "," Demand of a loan from his close relative was urgent whereas he needed the same money for his son’s hostel admission. He.. "," While traveling by train he went to toilet. On his return to his seat he found his briefcase missing. He..","He received conflicting orders from his two superior officers. He.."," He was appointed captain of basketball team but other players revolted against his appointment. He.."," An epidemic spread in the village due to poor hygiene conditions. He..","While he discussed his viewpoints others did not listen to him carefully. He..","He noticed a car moving with high speed running over a child on the road. He..","A fellow passenger fell from a running train. He.."," His parents wanted him to marry a wealthy and less educated girl, but he had already found a suitable educated girl for himself. He.."," He made a silly mistake and his friend pointed it out. He.. "," He heard his neighbor screaming ‘thief – thief’ at mid night. He.."," A fellow passenger in the train objected to his smoking being an offence in public place. He.."," He reached home from office and saw his house on fire. He.."," He was going to Delhi for an interview but realized after one hour that he has boarded a wrong train. He.. ","While he was going up in a lift the electric power supply failed. He.. "," While he was hosting a dinner to his friends in a hotel he realized that he has forgotten his wallet at home. He.. "," His friends came to borrow the book from which he was preparing for next morning paper. He.. ","He was appointed to supervise evening games in the college but he was staying far away. He.. ","He proposed to invite a political leader to preside over the annual day celebration but others were against it. He.. ","He had undergone a major surgical operation but there was no one to look after. He..","His parents were insisting on his early marriage but he wanted to take up a job first. He.. "," He realized that his seniors were giving step-motherly treatment to him. He.. "," Hearing an unusual sound at night he woke up and found a thief jumping out of his window. He.. "," He was going to attend SSB interview. On reaching the Railway Station he noticed that his suitcase has been stolen with his original certificates needed at SSB. He.."," While he was traveling on his scooter, someone at gunpoint demanded his purse. He.. "," He went to college but rowdy students told him to boycott the class. He.. "," His father had a dispute with his uncle on landed property. He.."," He wanted to borrow money for his sister’s marriage. The relative who assured him, declined to lend him at the time of marriage. He.. ","He was going on a bicycle in thick jungle. It was already dark and his destination was 10 Km away. His cycle got punctured. He.. "," He went to buy a ticket to travel by rail. On getting the ticket he found that his purse was missing. He.. "," While he was in a jungle in Nagaland, he saw six Nagas with lathis rushing to him. He.."," He was appointed Langar Commander. The dal has often been having stones which was complained by the dining members. He.."," He didn’t do well in written test of SCO Commission. His friends advised him not to venture in future. He.."," He was traveling in a train on reserved seat. A fellow passenger claimed to have the same seat on his reservation ticket. He.. "," He won a lottery of rupees one lakh. He.. ","His two school going children frequently missed the classes. He.. ","He was going to the market and he noticed a car and a tonga collide with each other. He.. ","He was asked to organize a picnic to a nearby historical place. He.. "," On returning to his barrack from the firing range, he found that his friend had brought 20 rounds of 7.62 mm SLR. He.. "," A helicopter crashed in the vicinity of his unit lines. He.."," He saw a rifle disc lying in the football field of his company. He.. ","A speeding motor truck ran over a man as he happened to pass by. He.. "," He was on a boat and he noticed mid stream water entering in the boat. He.. ","He and his sister were passing through a thick forest on a scooter. The scooter had stopped at gunpoint for ransom. He.. "," He was called upon to organize a variety entertainment show in aid of Jawans’ welfare in his unit. He.."," Due to financial difficulties his father couldn’t support him for further studies after he passed his metric examination. He.. "};
    String number[]={"sample","2/60","3/60","4/60","5/60","6/60","7/60","8/60","9/60","10/60","11/60","12/60","13/60","14/60","15/60","16/60","17/60","18/60","19/60","20/60","21/60","22/60","23/60","24/60","25/60","26/60","27/60","28/60","29/60","30/60","31/60","32/60","33/60","34/60","35/60","36/60","37/60","38/60","39/60","40/60","41/60","42/60","43/60","44/60","45/60","46/60","47/60","48/60","49/60","50/60","51/60","52/60","53/60","54/60","55/60","56/60","57/60","58/60","59/60","60/60"};

    Timer t = new Timer();
    public MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_srt_two);
        mp = MediaPlayer.create(this, R.raw.camera);

        t.scheduleAtFixedRate(
                new TimerTask() {
                    @Override
                    public void run() {


                        mp.start();


                    }
                }, 0,
                30000);

        final TextView textView=(TextView)findViewById(R.id.textid);
        final TextView textView1=(TextView)findViewById(R.id.srtno);

        Thread t=new Thread(){



            @Override
            public void run(){


                while(!isInterrupted()){

                    try {
                        Thread.sleep(30000);  //1000ms = 1 sec

                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                count++;
                                if (count < words.length){

                                    textView.setText(words[count]);
                                    textView1.setText(number[count]);

                                }else{
                                    srt_two.this.finish();
                                }
                            }
                        });

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        };

        t.start();

        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("SRT-2");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
    @Override
    protected void onPause() {
        t.cancel();
        super.onPause();
    }
}
