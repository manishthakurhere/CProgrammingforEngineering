package com.example.ssbcrackpractice;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class second_day extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_day);


        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("PSYCHOLOGY TESTS");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
    public void gototatone(View view)
    {
        Intent intent=new Intent(second_day.this,tat_one.class);
        startActivity(intent);
    }
    public void gototattwo(View view)
    {
        Intent intent1=new Intent(second_day.this,tat_two.class);
        startActivity(intent1);
    }
    public void gototatthree(View view)
    {
        Intent intent2=new Intent(second_day.this,tat_three.class);
        startActivity(intent2);
    }
    public void gototatfour(View view)
    {
        Intent intent3=new Intent(second_day.this,tat_four.class);
        startActivity(intent3);
    }
    public void gototatfive(View view)
    {
        Intent intent4=new Intent(second_day.this,tat_five.class);
        startActivity(intent4);
    }
    public void gototatsix(View view)
    {
        Intent intent5=new Intent(second_day.this,tat_six.class);
        startActivity(intent5);
    }
    public void gototatseven(View view)
    {
        Intent intent5=new Intent(second_day.this,tat_seven.class);
        startActivity(intent5);
    }
    public void gototateight(View view)
    {
        Intent intent5=new Intent(second_day.this,tat_eight.class);
        startActivity(intent5);
    }
    public void gototatnine(View view)
    {
        Intent intent5=new Intent(second_day.this,tat_nine.class);
        startActivity(intent5);
    }
    public void gototatten(View view)
    {
        Intent intent5=new Intent(second_day.this,tat_ten.class);
        startActivity(intent5);
    }
    public void gotowatone(View view)
    {
        Intent intent6=new Intent(second_day.this,wat_one.class);
        startActivity(intent6);
    }
    public void gotowattwo(View view)
    {
        Intent intent7=new Intent(second_day.this,wat_two.class);
        startActivity(intent7);
    }
    public void gotowatthree(View view)
    {
        Intent intent8=new Intent(second_day.this,wat_three.class);
        startActivity(intent8);
    }
    public void gotowatfour(View view)
    {
        Intent intent9=new Intent(second_day.this,wat_four.class);
        startActivity(intent9);
    }
    public void gotowatfive(View view)
    {
        Intent intent10=new Intent(second_day.this,wat_five.class);
        startActivity(intent10);
    }
    public void gotowatsix(View view)
    {
        Intent intent11=new Intent(second_day.this,wat_six.class);
        startActivity(intent11);
    }
    public void gotowatseven(View view)
    {
        Intent intent11=new Intent(second_day.this,wat_seven.class);
        startActivity(intent11);
    }
    public void gotowateight(View view)
    {
        Intent intent11=new Intent(second_day.this,wat_eight.class);
        startActivity(intent11);
    }
    public void gotowatnine(View view)
    {
        Intent intent11=new Intent(second_day.this,wat_nine.class);
        startActivity(intent11);
    }
    public void gotowatten(View view)
    {
        Intent intent11=new Intent(second_day.this,wat_ten.class);
        startActivity(intent11);
    }

    public void gotosrtone(View view)
    {
        Intent intent12=new Intent(second_day.this,srt_one.class);
        startActivity(intent12);
    }
    public void gotosrttwo(View view)
    {
        Intent intent13=new Intent(second_day.this,srt_two.class);
        startActivity(intent13);
    }
    public void gotosrtthree(View view)
    {
        Intent intent14=new Intent(second_day.this,srt_three.class);
        startActivity(intent14);
    }
    public void gotosrtfour(View view)
    {
        Intent intent15=new Intent(second_day.this,srt_four.class);
        startActivity(intent15);
    }
    public void gotosrtfive(View view)
    {
        Intent intent16=new Intent(second_day.this,srt_five.class);
        startActivity(intent16);
    }
    public void gotosrtsix(View view)
    {
        Intent intent17=new Intent(second_day.this,srt_six.class);
        startActivity(intent17);
    }
}
