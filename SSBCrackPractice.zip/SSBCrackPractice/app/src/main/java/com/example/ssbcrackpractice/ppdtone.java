package com.example.ssbcrackpractice;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.ViewFlipper;

public class ppdtone extends AppCompatActivity {
    int images[] = {R.drawable.ppone, R.drawable.ppdtwrite, R.drawable.ppdtwrite,  R.drawable.ppdtwrite,  R.drawable.ppdtwrite, R.drawable.ppdtwrite, R.drawable.ppdtwrite, R.drawable.ppdtwrite, R.drawable.ppdtwrite, R.drawable.ppdtwrite, R.drawable.ppdtwrite};
    ViewFlipper flipper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ppdtone);

        int images[] = {R.drawable.ppone, R.drawable.ppdtwrite, R.drawable.ppdtwrite,  R.drawable.ppdtwrite,  R.drawable.ppdtwrite, R.drawable.ppdtwrite, R.drawable.ppdtwrite, R.drawable.ppdtwrite, R.drawable.ppdtwrite, R.drawable.ppdtwrite, R.drawable.ppdtwrite};
        flipper = findViewById(R.id.flipper1);

        for(int i=0;i<11;i++) {
            flipperImages(images[i]);
        }

        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("PPDT-1");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    public void flipperImages(int image)
    {
        ImageView imageView=new ImageView(this);
        imageView.setBackgroundResource(image);

        flipper.addView(imageView);
        flipper.setFlipInterval(30000);
        flipper.setAutoStart(true);

    }

}
