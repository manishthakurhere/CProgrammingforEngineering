package com.example.ssbcrackpractice;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class oir_three extends AppCompatActivity {
    String [][] words=new String[][] {{" 'GOPAL'' is coded as '84321' and 'TREES' as 56779. Based on this, what is the code for 'GREAT'?" ," 'GOPAL'' is coded as '84321' and 'TREES' as 56779. Based on this, what is the code for 'PETER'?" ," Ajay walks 24 km towards East and turns to right hand side and takes a drive of another 10 km. He then turning to his right (drives towards West) another 10 km. He then turns to his left & walks another 8 km. After that, he turns to his right & travels 14 km. How far is he from his initial point & in which direction?" ," One morning after sunrise, Amrit was standing facing a pole. The shadow of the pole was forming on the left side. Which direction was Amrit facing?" ," Ahmedabad is to the southwest of Bangalore, Chennai is to the east of Ahmedabad and southeast of Bangalore and Delhi is to the north of Chennai in line with Ahmedabad-Bangal;ore. In which direction of Bangalore is Delhi located?" ," Pointing to a photograph. Bajpai said, \" He is the son of the only daughter of the father of my brother.\"  How Bajpai is related to the man in the photograph?" ," Choose the odd one out." ," Choose the odd one out." ," If + means *, / means -, * means / and - means +, what will be the value of 4 + 11 / 5 - 55 = ?" ," If + means -, - means *, * means /, / means +, then 15 * 3 / 15 + 5 - 2 = ?" ," Arrange the words given below in a meaningful sequence.\n1. Nation\t2. Village\t3. City\n4. District\t5. State" ," Arrange the words given below in a meaningful sequence.\n1. Caste\t2. Family\t3. Newly married Couple\n4. Clan\t5. Species" ," Odometer is to mileage as compass is to" ," Marathon is to race as hibernation is to" ," Window is to pane as book is to" ," Choose the word which is different from the rest" ," Choose the word which is different from the rest" ," Choose the word which is different from the rest" ," In a certain code language, if the value of ‘BLOCK’ = 13 and ‘CURTAIN’ = 27, then what is the value of the word ‘SCIENCE’?" ," In a certain code language, if the word ‘DISTANCE’ is coded as EDCINSAT, then how will you code ‘ACQUIRE’ in that language?" ," Pointing to Manju, Raju said, “The son of her only brother is the brother of my wife”. How is Manju related to Raju?" ," .A monkey starts climbing up a tree 20ft. tall. Each hour, it hops 3ft. and slips back 2ft. How much time would it take the monkey to reach the top?" ," Raju who is facing east, turns 1000 in the anti-clock-wise direction and then 1450 in the clock-wise direction. Which direction is he facing now?" ," A watch shows 4.30. If the minute hand points to east, in what direction will the hour hand point?" ,"  If ‘+’means ‘÷’,÷means ‘x’ ,’x’ means  ‘-‘ and ‘-‘ means ‘+’ ,then 10+2÷5-3÷4+2-1=?" ," Find the one which does not belong to that group ?" ," If, in a language, ‘one’ is called ‘two’, ‘two’ is called ‘three’, ‘three’ is called ‘four’, ‘four’ is called ‘five’ and ‘five’ is called ‘six’. Then what is the square of number 2?" ," At what time between 7 o'clock and 8 o'clock, will the hands of a clock be together?" ," What least possible 4-digit number, when divided by 12, 16, 18 and 20 leaves 21 as remainder?" ,"  Goitre caused by the deficiency of ………" ," Some green are blue. No blue are white., then" ," Choose the pair of numbers which comes next 75 65 85 55 45 85 35.." ," In a journey of 15 miles two third distance was travelled with 40 mph and remaining with 60 mph.How muvh time the journey takes" ,"  1, 5, 14, 30, ?, 91" ," Rearrange to form a meaningful word:\n 'vetdeo'" ," Which is the one that does not belong to the group?" ," Which is the one that does not belong to the group?" ," What comes next in series? \n 5, 16, 49, 104, ?" ," What comes next in series?\n 1, 6, 13, 22, 33, ?" ," Find a pair that is similar to the given pair of numbers:- 180:90" },

            {" 86725" ," 37576" ," 18 km south" ," North" ," Northeast" ," Maternal Uncle" ," Cuboid" ," Whale" ," None of these" ," 10" ," 2, 3, 4, 5, 1" ," 3, 2, 1, 4, 5" ," direction" ," sleep" ," page" ," Chicken" ," Veil" ," Eagle" ," 38" ," EARCIQU" ," Sister of father-in-law" ," 18 hours" ," South-East" ," North-East" ," 32" ," 27" ," Five" ," 38(2/11) minutes past 7 o’ clock" ,"  1461" ,"  Iodine" ," Some green are white" ," 25 85" ," 20 min" ," 55" ," devote" ," Volcano" ," Building" ," 181" ," 46" ," 2 : 1" },

            {" Q 1" ," Q 2" ," Q 3" ," Q 4" ," Q 5" ," Q 6" ," Q 7" ," Q 8" ," Q 9" ," Q 10" ," Q 11" ," Q 12" ," Q 13" ," Q 14" ," Q15" ," Q 16" ," Q 17" ," Q 18" ," Q 19" ," Q 20" ," Q 21" ," Q 22" ," Q 23" ," Q 24" ," Q 25" ," Q 26" ," Q 27" ," Q 28" ," Q 29" ," Q 30" ," Q 31" ," Q 32" ," Q 33" ," Q 34" ," Q 35" ," Q 36" ," Q 37" ," Q 38" ," Q 39" ," Q 40" }};

    String [] optionone=new String[] {" 85725" ," 37576" ,"  20 km East" ," East" ,"  South" ," Nephew" ," Square" ," Fish" ," -48.5" ," 0" ," 2, 3, 4, 5, 1" ," 2, 3, 1, 4, 5" ," speed" ," winter" ," novel" ," Chicken" ," Cap" ," Kiwi" ," 32" ," EACIQUR" ," Mother’s sister" ," 21 hours" ," South-East" ," North-West" ," 32 " ," 27" ," Three" ," 33(5/12) minutes past 7 o’ clock" ," 36" ," Vitamin D" ," Some green are white" ," 25 15" ," 40 min" ," 45" ," -" ," Tornado" ," Sand" ," 171" ," 44" ," 64 : 37" };
    String [] optiontwo=new String[] {" 86925" ," 39596" ," 18 km south" ," West" ," Southwest" ," Brother" ," Triangle" ," Snake" ," -11" ," 6" ," 2, 3, 4, 1, 5" ," 3, 4, 5, 1, 2" ," hiking" ," bear" ," page" ," Snake" ," Turban" ," Eagle" ," 36" ," ERCIAQU" ," Grandmother" ," 12 hours" ," South " ,"  South-East" ," 50" ,"  37" ," Four" ," 38(2/11) minutes past 7 o’ clock" ," 133" ," Iron" ," No white are green" ," 25 85" ," 30 min" ," 55" ," -" ," Volcano" ," Cement" ," 191" ," 45" ," 2 : 1" };
    String [] optionthree=new String[] {" 86725" ," 97576" ," 16 km West" ," North" ," North" ," Father" ," Rectangle" ," Crocodile" ," 79" ," 10" ," 1, 3, 5, 4, 2" ," 3, 2, 1, 4, 5" ," needle" ," dream" ," cover" ," Swan" ," Helmet" ," Emu" ," 38" ," EACRIUQ" ," Mother-in-law" ," 18 hours" ," North-West" ," North-East" ," 45" ," 47" ," Five" ," 35(7/11) minutes past 8 o’ clock" ," 144" ,"  Vitamin A" ," No green are white" ," 35 25" ," 120 min" ," 60" ," -" ," Storm" ," Building" ," 181" ," 46" ," 23 : 10" };
    String [] optionfour=new String[] {" 86625" ," 84346" ," 10 km South" ," South" ," Northeast" ," Maternal Uncle" ," Cuboid" ," Whale" ," None of these" ," 20" ," 1, 2, 3, 4, 5" ," 4, 5, 3, 2, 1" ," direction" ," sleep" ," glass" ," Crocodile" ," Veil" ," Ostrich" ," 34" ," EARCIQU" ," Sister of father-in-law" ," 15 hours" ," West" ," North" ," 150" ," 17" ," Six" ," 32(1/11) minutes before 8 o’ clock" ,"  1461" ,"  Iodine" ," None of the above" ,"  35 85" ," 20 min" ," 70" ," -" ," Hurricane" ," Wood" ," 161" ," 47" ," 137 : 112" };
    int counter=0;
    TextView option1;
    TextView option2;
    TextView option3;
    TextView option4;
    TextView tv;
    TextView tvt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oir_three);

        tv=(TextView)findViewById(R.id.tvid);
        tvt=(TextView)findViewById(R.id.tvt);
        Button b1=(Button)findViewById(R.id.ans);
        Button b2=(Button)findViewById(R.id.nex);
        option1=(TextView)findViewById(R.id.op1);
        option2=(TextView)findViewById(R.id.op2);
        option3=(TextView)findViewById(R.id.op3);
        option4=(TextView)findViewById(R.id.op4);



        tv.setText(words[0][counter]);
        tvt.setText(words[2][counter]);
        option1.setText(optionone[counter]);
        option2.setText(optiontwo[counter]);
        option3.setText(optionthree[counter]);
        option4.setText(optionfour[counter]);


        counter=1;

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv.setText(words[0][counter]);
                tvt.setText(words[2][counter]);
                option1.setText(optionone[counter]);
                option2.setText(optiontwo[counter]);
                option3.setText(optionthree[counter]);
                option4.setText(optionfour[counter]);




                if(counter<words[0].length)
                {
                    counter++;
                }
                else
                {
                    finish();
                }

            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast tea= Toast.makeText(oir_three.this,words[1][counter-1],Toast.LENGTH_SHORT);
                tea.show();


            }
        });




        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("OIR-3" );
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

}
