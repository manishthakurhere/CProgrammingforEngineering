package com.example.ssbcrackpractice;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class oir_six extends AppCompatActivity {
    String [][] words=new String[][] {{"  If 'MLT' means 'Day is Clear' , 'LKS' means 'Life is Sad', 'SMMO' means 'Clear or Sad' , Then what is the code used for 'Day'?" ," If 'SAVOURY' is coded as 'OVUARSY' , them how will 'RADIATE' be coded?" ," Sandeep walks 60m to the east, then he turns left and walks for 50 m, then turns right and went 70 m and then turns right again and went 50 m. How far was Sandeep from the starting point?" ," I drove 50 km towards east from a city ‘S’ and then turned right and drove another 30 km. Now I turned to my left & drove another 30 km. Finally I turned my right & drove 30 km to reach a city ‘F’. Find the shortest straight distance between cities S and F." ," Introducing a boy, a girl said, \" He is the son of the daughter of the father of my uncle.\"  How is the boy related to the girl?" ," Today is Monday. After 61 days, it will be :" ,"  Next term in the Series 3, 10, 101,?" ," In the series 2, 6, 18, 54, ...... what will be the 8th term ?" ,"  Find the one which does not belong to that group ?" ," Choose the odd one out." ," Choose the odd one out." ,"  If + means /, * means -, / means * and - means +, then 8 + 6 * 4 / 3 - 4 = ?" ,"  If * means /, - means *, / means + and + means -, then (3 - 15 / 19) * 8 + 6 = ?" ," Arrange the words given below in a meaningful sequence.\n1. Poverty\t2. Population\t3. Death\n4. Unemployment\t5. Disease" ," Arrange the words given below in a meaningful sequence.\n1. Leaf\t2. Fruit\t3. Stem\n4. Root\t5. Flower" ," Sponge is to porous as rubber is to" ," Careful is to cautious as boastful is to" ," Pen is to poet as needle is to" ," Choose the word which is different from the rest." ," Choose the word which is different from the rest." ," Choose the word which is different from the rest." ," Make a meaningful word from 'LOGEB'" ," If a light flashes every 6 seconds, how many times will it flash in 3/4 of an hour?" ," What is the angle between the two hands of a clock when the time shown by the clock is 5.30 p.m. ?" ," Vishwanath was walking on the road early morning after the sunrise and his shadow was failing to his left. Which direction was he facing?" ," If4©5=189 and 10©8=1512,then 6©9=" ," Choose the word which is not similar to the other words in the group." ," If Karan says, “Rocky’s mother is the only daughter of my mother”, How is Karan related to Rocky?" ," Choose the odd pair of words" ," Pointing towards a girl, a man said to a woman, 'Her mother is the only daughter of your mother.' How is the girl related to that woman? " ," At what angle the hands of a clock are inclined at 40 minutes past 2?" ,"  If ‘blue’ means ‘green’, ‘green’ means ‘yellow’, ‘yellow’ means ‘orange’, ‘orange’ means ‘black’, ‘black’ means ‘white’, ‘white’ means ‘red’, ‘red’ means ‘pink’, ‘pink’ means ‘brown’, ‘brown’ means ‘grey’, then what is the color of human blood?" ," Choose the word which is least like the other words in the group." ," B is in the East of A which is in the North of C. If P is in the South of C, then in which direction of B, is P?" ," A man said to a lady, 'Your mother’s husband’s sister is my aunt'.How is the lady related to the man?" ," Rearrange to form a meaningful word: 'tercnia'" ," A jogger is running at a speed of 15 km/hr. In what time he will cross a track of length 400 meters?" ," The day on 5th April of a year will be the same day on 5th of which month of the same year?" ,"  Among A, B, C, D and E each having scored different marks, B has scored more marks than E and D, B has not scored the highest marks among them. Who among them scored second highest marks?" ,"  Which is the one that does not belong to the group?" },
            {" T" ," IDAATRE" ," 130 m" ," 100 km" ," Brother" ," Saturday" ," 10202" ," 4374" ," 4" ," Ounce" ," Thermodynamics" ," -20 / 3" ," 2" ," 2, 4, 1, 5, 3" ," 4, 3, 1, 5, 2" ," elastic" ," arrogant" ," tailor" ," Locust" ," Calendar" ," Groundnut" ," GLOBE" ," 451" ," 15" ," North" ," 945" ," Cycle" ," Uncle" ," Boar - Sow" ," Daughter" ," 160" ," White" ," Mustard" ," South-West" ," Sister" ," certain" ," 96 sec" ," 5th July" ," Data inadequate" ," Brass" },

            {" Q 1" ," Q 2" ," Q 3" ," Q 4" ," Q 5" ," Q 6" ," Q 7" ," Q 8" ," Q 9" ," Q 10" ," Q 11" ," Q 12" ," Q 13" ," Q 14" ," Q15" ," Q 16" ," Q 17" ," Q 18" ," Q 19" ," Q 20" ," Q 21" ," Q 22" ," Q 23" ," Q 24" ," Q 25" ," Q 26" ," Q 27" ," Q 28" ," Q 29" ," Q 30" ," Q 31" ," Q 32" ," Q 33" ," Q 34" ," Q 35" ," Q 36" ," Q 37" ," Q 38" ," Q 39" ," Q 40" }};

    String [] optionone=new String[] {" T" ," AIDARET" ," 90 m" ," 20 km" ," Brother" ," Tuesday" ," 10101" ," 4370" ," 3" ," Dollar" ," Geometry" ,"  -12" ," 8" ," 2, 3, 4, 5, 1" ," 3, 4, 5, 1, 2" ," massive" ," arrogant" ," thread" ," Chameleon" ," Calendar" ," Cumin" ," -" ," 450" ," 0" ," East" ," 945" ," Car" ," Brother" ," Badger - Cub" ," Sister" ," 150" ," Black" ," Coconut" ," South-East" ," Mother" ," -" ," 96 sec" ," 5th July" ," B" ," Copper" };
    String [] optiontwo=new String[] {" K" ," IDARATE" ," 70 m" ," 25 km" ," Nephew" ," Monday" ," 10201" ," 4374" ," 4" ," Peso" ," Algebra" ," -20 / 3" ," 4" ," 3, 4, 2, 5, 1" ," 4, 3, 1, 5, 2" ," solid" ," humble" ," button" ," Crocodile" ," Year" ," Groundnut" ," -" ," 451" ," 5" ," North " ," 1148" ," Cycle" ," Father" ," Boar - Sow" ," Daughter" ," 160" ," Red" ," Flax" ," South-West" ," Sister" ," -" ," 100 sec" ," 5th August" ," C" ," Brass" };
    String [] optionthree=new String[] {" MO" ," ARIADTE" ," 130 m" ," 30 km" ," Uncle" ," Sunday" ," 10202" ," 7443" ," 5" ," Ounce" ," Calculus" ," 12" ," 2" ," 2, 4, 1, 5, 3" ," 4, 1, 3, 5, 2" ," elastic" ," joyful" ," sewing" ," Alligator" ," Date" ," Cinnamon" ," -" ," 350" ," 3" ," West" ," 983" ," Helicopter" ," Uncle" ," Beaver - Pup" ," Aunt" ," 170" ," White" ," Castor" ," South" ," Daughter" ," -" ," 104 sec" ," 5th June" ," E" ,"  Iron" };
    String [] optionfour=new String[] {" L" ," IDAATRE" ," 100 m" ," 100 km" ," Son-in-law" ," Saturday" ," 11012" ," 7434" ," 9" ," Euro" ," Thermodynamics" ," 20 / 3" ," -1" ," 1, 2, 3, 4, 5" ," 4, 3, 1, 2, 5" ," inflexible" ," suspicious" ," tailor" ," Locust" ," Month" ," Pepper" ," -" ," 425" ," 15" ," Either East or West" ," 764" ," Airplane" ," Grandfather" ," Hawk - Eyas" ," Wife" ," 180" ," Orange" ," Mustard" ," North" ," Aunt" ," -" ," 110 se" ," 5th October" ," Data inadequate" ," Aluminium" };
    int counter=0;
    TextView option1;
    TextView option2;
    TextView option3;
    TextView option4;
    TextView tv;
    TextView tvt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oir_six);

        tv=(TextView)findViewById(R.id.tvid);
        tvt=(TextView)findViewById(R.id.tvt);
        Button b1=(Button)findViewById(R.id.ans);
        Button b2=(Button)findViewById(R.id.nex);
        option1=(TextView)findViewById(R.id.op1);
        option2=(TextView)findViewById(R.id.op2);
        option3=(TextView)findViewById(R.id.op3);
        option4=(TextView)findViewById(R.id.op4);



        tv.setText(words[0][counter]);
        tvt.setText(words[2][counter]);
        option1.setText(optionone[counter]);
        option2.setText(optiontwo[counter]);
        option3.setText(optionthree[counter]);
        option4.setText(optionfour[counter]);


        counter=1;

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv.setText(words[0][counter]);
                tvt.setText(words[2][counter]);
                option1.setText(optionone[counter]);
                option2.setText(optiontwo[counter]);
                option3.setText(optionthree[counter]);
                option4.setText(optionfour[counter]);




                if(counter<words[0].length)
                {
                    counter++;
                }
                else
                {
                    finish();
                }

            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast tea= Toast.makeText(oir_six.this,words[1][counter-1],Toast.LENGTH_SHORT);
                tea.show();


            }
        });



        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("OIR-6" );
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

}
