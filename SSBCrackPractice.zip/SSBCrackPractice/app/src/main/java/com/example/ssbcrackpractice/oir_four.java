package com.example.ssbcrackpractice;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class oir_four extends AppCompatActivity {
    String [][] words=new String[][] {{"  If 'CASE' is coded as 5231 , 'CHAIR' as 58206, 'TEACH' as 71258, then what does 586037 stand for? " ," If 'SPANK' is coded as 'PSNAK' , then how will 'THROW' be coded?" ," Raju walks 80 ms towards south. Then, turns to his right & starts walking straight till he completes another 80 ms. Then, again turning to his left he walks for 60 metres. He then turns to his left & walks for 80 metres. How far is he from his initial position?" ," One evening just before sunset two friends Sanju and Manju were talking to each other face to face. If Manju’s shadow was exactly to her left side, which direction was Sanju facing?" ," Ajay drives 3 kilometres North. Then he turns right and drives 4 kilo metres. Now he turns right and drives 5 kilometres. Now turning left, he drives 2 kilometres. Again, he turns left and moves 2 kilometres. Finally turning left he again walks 2 kilometres. In which direction & how far is he from his starting position?" ," Pointing a photograph X said to his friend Y, \" She is the only daughter of the father of my mother.\"  How X is related to the person of photograph?" ," Choose the odd one out." ," Choose the odd one out." ," If P denotes +, Q denotes *, R denotes / and S denotes -, then 18 Q 12 P 4 R 5 S 6 = ?" ," Arrange the words given below in a meaningful sequence. \n1. Key\t2. Door\t3. Lock\n4. Room\t5. Switch on" ," Arrange the words given below in a meaningful sequence.\n1. Word\t2. Paragraph\t3. Sentence\n4. Letters\t5. Phrase" ," Cup is to coffee as bowl is to" ," Yard is to inch as quart is to" ," Elated is to despondent as enlightened is to" ," Choose the word which is different from the rest." ," Choose the word which is different from the rest." ," Choose the word which is different from the rest." ," In a certain code language, if the value of 28 + 14 = 50 and 36 + 43 =63, then what is the value of 44 + 52 =?" ," In a certain code language, if the value of 14 x 15 = 25 and 26 x 42 =64, then what is the value of 73 x 31 = ?" ," A is the husband of B. E is the daughter of C. A is the father of C. How is B related to E?" ," Mr.Ramu’s mother’s father-in-law’s only son’s only daughter’s son is Chetan. How is Ramu related to Chetan?" ,"  In the time in which the second hand covers 3960 degrees, how many degrees does the hour hand move?" ,"  If  today is Thursday , after 730 days which will be the day of the week ?" ," After walking 6 kms, I turned right and travelled a distance of 2 kms, then turned left and covered a distance of 10 km. In the end I was moving towards the north. From which direction did I start my journey?" ," If 5@6=61 and 8@10=164,then 7@9=?" ," If ‘dog’ is called ‘lion’, ‘lion’ is called ‘bison’, ‘bison’ is called ‘snake’, ‘snake’ is called ‘mongoose’, ‘mongoose’ is called ‘crocodile’, then which one is reared as pet?" ," Next number in the pattern 1, 4, 8, 13, ?, 26, ?" ," Pointing to a man, Rohan said, “His only brother is the father of my daughter’s father.” How is the Rohan related to the man?" ," At what angle are the hands of a clock inclined at 15 minutes past 4?" ," Unscramble the word 'YSLET" ," Find what is the next letter. Please try to find. O,T,T,F,F,S,S,E,N,_ What is that letter?" ,"  A is twice as good a workman as B and together they finish a piece of work in 18 days.In how many days will A alone finish the work?" ," Which one of the words given below is different from others?" ," Complete the series: 5, 20, 24, 6, 2, 8, ?" ," ₹1000 is to be divided among A, B and C so that A gets twice as B and B gets thrice as C. The share of C will be" ," Ten years ago, P was half of Q’s age. If the ratio of their present ages is 3 : 4, what will be the total of their present ages?" ," Rearrange to form a meaningful word: 'sonles'" ," Which is the one that does not belong to the group?" ," Which is the one that does not belong to the group?" ," In a certain code language ‘over and above’ is written as ‘da pa ta’ and ‘old and beautiful’ is written as ‘sa na pa;. How is ‘over’ written in that code language?" },
            {" CHRIST" ," HTORW" ," 140 meters" ,"  North" ," 4 kilometres East" ," Son" ," Sword" ," Loyalty" ," 53" ," 1, 3, 2, 4, 5" ," 4, 1, 5, 3, 2" ," soup" ," ounce" ," ignorant" ," Ayurveda" ," Oil" ," Park" ," 56" ," 100" ," Grandmother" ," Uncle" ," 5.5" ," Saturday " ," South " ," 130 " ," Lion" ," 19" ," Nephew" ," 37.5" ," STYLE" ," T" ," 27" ," Apricot" ," 12" ," 100" ," 35" ," lesson" ," Cousin" ," Plate" ," da or ta" },

            {" Q 1" ," Q 2" ," Q 3" ," Q 4" ," Q 5" ," Q 6" ," Q 7" ," Q 8" ," Q 9" ," Q 10" ," Q 11" ," Q 12" ," Q 13" ," Q 14" ," Q15" ," Q 16" ," Q 17" ," Q 18" ," Q 19" ," Q 20" ," Q 21" ," Q 22" ," Q 23" ," Q 24" ," Q 25" ," Q 26" ," Q 27" ," Q 28" ," Q 29" ," Q 30" ," Q 31" ," Q 32" ," Q 33" ," Q 34" ," Q 35" ," Q 36" ," Q 37" ," Q 38" ," Q 39" ," Q 40" }};

    String [] optionone=new String[] {" CHASTE" ," HTORW" ," 100 metres" ,"  North" ," 1.5 kilometres East" ," Daughter" ," Spoon" ," Unfaithfulness" ," 36" ," 5, 1, 2, 4, 3" ," 4, 1, 5, 2, 3" ," dish" ," gallon" ," aware" ," Rigveda" ," Curd" ," Hangar" ," 54" ," 100" ," Mother" ," Uncle" ," 11" ," Thursday " ," North " ," 125" ," Lion" ," 15" ," Father" ," 32" ," -" ," B" ," 27" ," Orange" ," 12" ," 600" ," 45" ," -" ," Cousin" ," Cup" ," da" };
    String [] optiontwo=new String[] {" CHRIST" ," HTWOR" ," 60 metres" ," South" ," 4 kilometres East" ," Son" ," Sword" ," Loyalty" ," 53" ," 4, 2, 1, 5, 3" ," 4, 1, 3, 5, 2" ," soup" ," milk" ," ignorant" ," Yajurveda" ," Butter" ," Platform" ," 56" ," 110" ," Grandmother" ," Nephew" ," 5.5" ," Friday" ," South " ," 63" ," Bison" ," 19" ," Grandson" ,"  37" ," -" ," S" ," 26" ," Grape" ," 32" ," 300" ," 40" ," -" ," Nephew" ," Jug" ," ta" };
    String [] optionthree=new String[] {" STREET" ," HTWRO" ," 20 metres" ," West" ," 4.5 metres West" ," Nephew" ,"  Knife" ," Betrayal" ," 59" ," 1, 3, 2, 4, 5" ," 4, 2, 5, 1, 3" ," spoon" ," liquid" ," miserable" ," Atharvaveda" ," Oil" ," Dock" ," 58" ," 90" ," Aunt" ," Niece" ," 3/4" ," Saturday " ," South-West" ," 130 " ," Snake" ," 20" ," Uncle" ," 32.5" ," -" ," Q" ," 25" ," Apricot" ," 34" ," 200" ," 35" ," -" ," Mother" ," Tumbler" ," na" };
    String [] optionfour=new String[] {" CHEESE" ," HTRWO" ," 140 meters" ," Data inadequate" ," None of these" ," Cannot be decided" ," Fork" ,"  Infidelity" ," 65" ," 1, 2, 3, 5, 4" ," 4, 1, 5, 3, 2" ," food" ," ounce" ," tolerant" ," Ayurveda" ," Cheese" ," Park" ," 62" ," 120" ," Cousin" ," Father" ," 55" ," Monday" ," North-East" ," 32" ," Mongoose" ," 21" ," Nephew" ," 37.5" ," -" ," T" ," 24" ," Raspberry" ," 36" ," 100" ," 30" ," -" ," Brother" ," Plate" ," da or ta" };
    int counter=0;
    TextView option1;
    TextView option2;
    TextView option3;
    TextView option4;
    TextView tv;
    TextView tvt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oir_four);

        tv=(TextView)findViewById(R.id.tvid);
        tvt=(TextView)findViewById(R.id.tvt);
        Button b1=(Button)findViewById(R.id.ans);
        Button b2=(Button)findViewById(R.id.nex);
        option1=(TextView)findViewById(R.id.op1);
        option2=(TextView)findViewById(R.id.op2);
        option3=(TextView)findViewById(R.id.op3);
        option4=(TextView)findViewById(R.id.op4);



        tv.setText(words[0][counter]);
        tvt.setText(words[2][counter]);
        option1.setText(optionone[counter]);
        option2.setText(optiontwo[counter]);
        option3.setText(optionthree[counter]);
        option4.setText(optionfour[counter]);


        counter=1;

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv.setText(words[0][counter]);
                tvt.setText(words[2][counter]);
                option1.setText(optionone[counter]);
                option2.setText(optiontwo[counter]);
                option3.setText(optionthree[counter]);
                option4.setText(optionfour[counter]);




                if(counter<words[0].length)
                {
                    counter++;
                }
                else
                {
                    finish();
                }

            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast tea= Toast.makeText(oir_four.this,words[1][counter-1],Toast.LENGTH_SHORT);
                tea.show();


            }
        });




        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("OIR-4" );
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

}
