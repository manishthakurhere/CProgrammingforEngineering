package com.example.ssbcrackpractice;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    AdView mAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        MobileAds.initialize(this,"ca-app-pub-6692454266263355~7547039103");

        mAdView=(AdView)findViewById(R.id.adView);
        AdRequest adRequest=new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_olqs) {
            gotoolq();
        } else if (id == R.id.nav_entries) {
            gotoentries();


        } else if (id == R.id.nav_ta) {
            gotoaboutta();

        } else if (id == R.id.nav_stay) {
            gotostay();

        }  else if (id == R.id.nav_rate_us) {
            rate_us();

        }   else if (id == R.id.nav_samples) {
                samples();


            } else if (id == R.id.nav_share) {


            {
                try {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, "SSB Practice ");
                    String shareMessage= "\nLet me recommend you this application\n\n";
                    shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID +"\n\n";
                    shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                    startActivity(Intent.createChooser(shareIntent, "choose one"));
                } catch(Exception e) {
                    //e.toString();
                }
            }

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public void click_one(View view)
    {
        Intent intent=new Intent(MainActivity.this,about_ssb.class);
        startActivity(intent);
    }
    public void click_two(View view)
    {
        Intent intent=new Intent(MainActivity.this,first_day.class);
        startActivity(intent);
    }
    public void click_three(View view)
    {
        Intent intent=new Intent(MainActivity.this,second_day.class);
        startActivity(intent);
    }
    public void click_four(View view)
    {
        Intent intent=new Intent(MainActivity.this,third_day.class);
        startActivity(intent);
    }
    public void click_five(View view)
    {
        Intent intent=new Intent(MainActivity.this,fourth_day.class);
        startActivity(intent);
    }
    public void click_six(View view)
    {
        Intent intent=new Intent(MainActivity.this,fifth_day.class);
        startActivity(intent);
    }
    public  void gotoolq()
    {
        Intent intent=new Intent(MainActivity.this,olqs.class);
        startActivity(intent);
    }
    public  void gotoentries()
    {
        Intent intent=new Intent(MainActivity.this,entries.class);
        startActivity(intent);
    }
    public  void gotoaboutta()
    {
        Intent intent=new Intent(MainActivity.this,ta.class);
        startActivity(intent);
    }
    public  void gotostay()
    {
        Intent intent=new Intent(MainActivity.this,stay.class);
        startActivity(intent);
    }

    public void send_mail(View view)
    {
        Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                "mailto","manishthakurhere@gmail.com", null));

        startActivity(Intent.createChooser(intent, "Choose an Email client :"));
    }
    public void rate_us()
    {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + "SSB GUIDE")));
    }
    public void samples()
    {
        Intent intent=new Intent(MainActivity.this,samples.class);
        startActivity(intent);
    }

}
