package com.example.ssbcrackpractice;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ViewFlipper;

public class slideshow extends AppCompatActivity {
    int images[]={R.drawable.dayone,R.drawable.daytwo,R.drawable.daythree,R.drawable.dayfour,R.drawable.dayfive};
    ViewFlipper flipper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slideshow);

        int images[] = {R.drawable.dayone, R.drawable.daytwo, R.drawable.daythree, R.drawable.dayfour, R.drawable.dayfive};
        flipper = findViewById(R.id.flipper1);

for(int i=0;i<5;i++) {
    flipperImages(images[i]);
}

    }

    public void flipperImages(int image)
    {
        ImageView imageView=new ImageView(this);
        imageView.setBackgroundResource(image);

        flipper.addView(imageView);
        flipper.setFlipInterval(2000);
        flipper.setAutoStart(true);
        flipper.setInAnimation(this,android.R.anim.slide_out_right);

    }

}
