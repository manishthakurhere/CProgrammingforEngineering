package com.example.ssbcrackpractice;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class third_day extends AppCompatActivity {

    ExpandableListView expandableListView;
    List  <String> question;
    Map<String,List<String>> answer;
    ExpandableListAdapter listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_day);



        expandableListView = (ExpandableListView)findViewById(R.id.expandableListView);
        fillData();

        listAdapter=new MyexListadapter(this,question,answer);
        expandableListView.setAdapter(listAdapter);


        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {



                return true;
            }
        });

        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("INTERVIEW/GTO");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    public void fillData()
    {
        question=new ArrayList<>();
        answer = new HashMap<>();

        question.add(" About Personal Interview");
        question.add(" DOs and DON'Ts");
        question.add(" TIPS");
        question.add(" SELF");
        question.add(" FRIENDS");
        question.add(" FAMILY");
        question.add(" HOBBIES");
        question.add(" EDUCATION");
        question.add(" JOB");
        question.add(" RAPID FIRE");
        question.add(" DEFENSE RELATED");
        question.add(" TECHNICAL");
        question.add(" GAMES/SPORTS");
        question.add(" TRICKY QUESTIONS");


        List<String> one = new ArrayList<>();
        List<String> two= new ArrayList<>();
        List<String> three= new ArrayList<>();
        List<String> four= new ArrayList<>();
        List<String> five= new ArrayList<>();
        List<String> six= new ArrayList<>();
        List<String> seven= new ArrayList<>();
        List<String> eight= new ArrayList<>();
        List<String> nine= new ArrayList<>();
        List<String> ten= new ArrayList<>();
        List<String> eleven= new ArrayList<>();
        List<String> twelve= new ArrayList<>();
        List<String> thirteen= new ArrayList<>();
        List<String> forteen= new ArrayList<>();


        one.add("* Personal Interview is a one to one conversation between the candidate and a high ranked officer of the SSB Board known as Interviewing Officer. Although the Personal Interview \n" +
                "  is a part of testing procedure in almost all types of job selection processes, but SSB PI is nothing like them. Personal Interview is the most important part of the SSB Procedure \n" +
                "  and carries the most number of marks in the SSB Testing process. Moreover since PI is a matter of only one small test, it is easy as well as important.\n" +
                "\n" +
                "* The length of the Interview may vary from twenty minutes to an hour (generally) although the duration of the Interview has nothing to do with a candidate's selection\n" +
                "  as the quality of the interview matters more. \n" +
                "\n" +
                "* Candidates are expected to be in formal attire, however if a candidate is asked to appear for PI in the middle of Group Testing , one can attend it in the Group testing attire only.\n" +
                "\n" +
                "* If a candidate has mentioned about some achievements in the PIQ form, he/she is expected to carry those certificates, arranged, in a folder with him/her. \n" +
                "\n" +
                "* In some cases, there may be two Interviewers in the room, one of which is training Officer and has nothing to do with the candidate's interview. \n" +
                "\n" +
                "* The Interview may include versatile questions ranging from the candidate's academic, profession, and personal life.\n" +
                "\n");

        two.add("DO's\n" +
                "\n" +
                "* Prefer a light colored shirt with dark colored trousers and formal shoes.\n" +
                "\n" +
                "* Do make sure clothes are ironed.\n" +
                "\n" +
                "* Do sit straight and comfortably.\n" +
                "\n" +
                "* Do make sure your hair is in place and conservative\n" +
                "\n" +
                "* Do smile and remain calm. \n" +
                "\n" +
                "* Do look smart, cheerful and enthusiastic.\n" +
                "\n" +
                "* Do walk straight with confidence and ask for permission to sit.\n" +
                "\n" +
                "* Be audible but not too loud.\n" +
                "\n" +
                "* Maintain a proper eye contact (without staring).\n" +
                "\n" +
                "* Be truthful and honest with your answers.\n" +
                "\n" +
                "* Do listen to complete questions before attempting to reply.\n" +
                "\n" +
                "* Do utilize your time while waiting for interview by reading newspapers and journals available in waiting room.\n" +
                "\n" +
                "* Do find out answers of unanswered questions after interview as they may be asked during conference.\n" +
                "\n" +
                "* Give logical and crisp answers.\n" +
                "\n" +
                "\n" +
                "DON'Ts\n" +
                "\n" +
                "* Don't peep through the door if you are waiting for you turn.\n" +
                "\n" +
                "* Don't enter/sit without permission.\n" +
                "\n" +
                "* Don't lie/boast about yourself.\n" +
                "\n" +
                "* Don't Panic or get Nervous.\n" +
                "\n" +
                "* Don't fidget.\n" +
                "\n" +
                "* Avoid guessing answers , politely admit not knowing an answer.\n" +
                "\n" +
                "* Don't unnecessarily argue with interviewer.\n" +
                "\n" +
                "* Don't contradict your PIQ or Self description.\n" +
                "\n" +
                "* Don't come under stress.");



        three.add("* The first and foremost thing is the confidence.\n" +
                "\n" +
                "* Walk and sit in a proper and firm posture, and always talk in a respectful, modulated voice.\n" +
                "\n" +
                "* Greet the IO , when you enter the room.\n" +
                "\n" +
                "* Wear clean, well ironed , comfortable clothes.\n" +
                "\n" +
                "* Remember that the interview is all about self introspection.\n" +
                "\n" +
                "* Interview is not about GK or academic knowledge, as it has already been tested in your eligibility criterion for the SSB Interview.(Written Test)\n" +
                "\n" +
                "* Although, having knowledge about surroundings and current happenings gives a plus point.\n" +
                "\n" +
                "* The Questions about family, friends, defense etc. need to be prepared beforehand.\n" +
                "\n" +
                "* Always have an example prepared for any quality you state about yourself or your friends/family as the interviewer might ask for one.\n" +
                "\n" +
                "* Interviewer might deliberately ask questions to make the candidate uncomfortable, avoid coming under stress.\n" +
                "\n" +
                "* Remain calm even when Interviewer tries to put you under stressful situations.\n" +
                "\n" +
                "* Avoid being extra friendly and answer what you feel is mature and right.\n" +
                "\n" +
                "* In the rapid fire questions, you might lose track of the sequence of the questions he asks, so pay attention as the questions are logically connected.\n" +
                "\n" +
                "* However, if you miss some questions, continue with the rest.\n" +
                "\n" +
                "* Being confident is the key to success here.\n" +
                "\n" +
                "* Never contradict what you have written in the PIQ.\n" +
                "\n" +
                "* Never exaggerate or lie in the Interview.\n");

        four.add("* Tell me something about yourself\n" +
                "\n" +
                "* Why do you want to join Indian Army/Navy/Air Force? \n" +
                "\n" +
                "* What is the meaning of your name?\n" +
                "\n" +
                "* What makes you unique?\n" +
                "\n" +
                "* Tell me about your family.\n" +
                "\n" +
                "* How did you prepare for SSB interview?\n" +
                "\n" +
                "* Did you take any coaching for SSB?\n" +
                "\n" +
                "* What are your strengths and weaknesses?\n" +
                "\n" +
                "* Why did you not get recommended last time? (repeaters)\n" +
                "\n" +
                "* What accomplishments are you most proud of?\n" +
                "\n" +
                "* What is the speciality of the place you belong to?\n" +
                "\n" +
                "* Where and when were you born?\n" +
                "\n" +
                "* How was the journey to SSB Center?\n" +
                "\n" +
                "* Which major stations came in the way?\n" +
                "\n" +
                "* What are your achievements?\n" +
                "\n" +
                "* Do you do household chores? which ones?\n" +
                "\n" +
                "* What qualities do you like about your best friend?\n" +
                "\n" +
                "* Do you have a pet?  Describe it.\n" +
                "\n" +
                "* Tell me about your  favorite teacher.\n" +
                "\n" +
                "* What do you like about your favorite teacher?\n" +
                "\n" +
                "* Did you join NCC/ Scouts in school/college? If not, why?\n" +
                "\n" +
                "* Who is your inspiration\n" +
                "\n" +
                "* What is your greatest fear?\n" +
                "\n" +
                "* What makes you angry?\n" +
                "\n" +
                "* On a scale of 1 to 10 how would you rate yourself as a leader?\n" +
                "\n" +
                "* Why should we recommend you?\n" +
                "\n" +
                "* What are your other career options?\n" +
                "\n" +
                "* Give examples from your life that show that you are a responsible person?\n" +
                "\n" +
                "* Do you have any questions for me?\n");

        five.add("* Tell me about your friend circle.\n" +
                "\n" +
                "* How many friends do you have?\n" +
                "\n" +
                "* How many of your friends are Males/Females?\n" +
                "\n" +
                "* What do your friends think about you?\n" +
                "\n" +
                "* Compare yourself with your best friend.\n" +
                "\n" +
                "* What qualities do you look for while making a friend?\n" +
                "\n" +
                "* How do you help your friends?\n" +
                "\n" +
                "* How do you spend free time with friends?\n" +
                "\n" +
                "* How do you resolve differences with your friends?\n" +
                "\n" +
                "* What is your best memory with your friends?\n" +
                "\n" +
                "* Which friend of yours inspires you and why?\n" +
                "\n" +
                "* Have you ever lied to your best friend? What was it about?\n" +
                "\n");

        six.add("* What is the Occupation of your parents.\n" +
                "\n" +
                "* What is the meaning of parent's names?\n" +
                "\n" +
                "* What is your family income?\n" +
                "\n" +
                "* Who among your parents are you more close to and why?\n" +
                "\n" +
                "* How do you help your father?\n" +
                "\n" +
                "* How do you help your mother?\n" +
                "\n" +
                "* Compare yourself with you brother/sister.\n" +
                "\n" +
                "* How do you spend time with your family?\n" +
                "\n" +
                "* How do you help your brother/sister?\n" +
                "\n" +
                "* Have you ever lied to your parents? What was it about?\n" +
                "\n");
        seven.add("* what are your hobbies.\n" +
                "\n" +
                "* Why did you choose this hobby?\n" +
                "\n" +
                "* How long have you been pursuing this hobby?\n" +
                "\n" +
                "* How do you take out time from your day's schedule for hobbies?\n" +
                "\n" +
                "* How is this hobby helping you improve yourself?\n" +
                "\n" +
                "* Do you think you can make a career of your hobbies?\n" +
                "\n" +
                "* Cross Questions about hobbies to be expected.\n" +
                "\n");
        eight.add("* Marks in class 10th / 12th / Graduation \n" +
                "\n" +
                "* Reason for variation of marks?\n" +
                "\n" +
                "* What is your favorite subject and why?\n" +
                "\n" +
                "* Which subject you don't like and why?\n" +
                "\n" +
                "* Who is your favorite teacher and why?\n" +
                "\n" +
                "* Which teacher you don't like and why?\n" +
                "\n" +
                "* What is your definition for a good teacher?\n" +
                "\n" +
                "* What do your teachers think about you?\n" +
                "\n" +
                "* What responsibilities do your teachers give you?\n" +
                "\n" +
                "* What are your achievements in academics? \n" +
                "\n" +
                "* Why is there a gap between your academic years? (if any)\n" +
                "\n" +
                "* Whom do you approach in case of difficulty in academics?\n" +
                "\n" +
                "* Tell me the things you like/dislike about your school/college\n" +
                "\n" +
                "* What have you read recently?");
        nine.add("* Describe your current organization.\n" +
                "\n" +
                "* What is your salary currently, are you happy with it?\n" +
                "\n" +
                "* What do you dislike about your current job?\n" +
                "\n" +
                "* What do you like/dislike about your boss?\n" +
                "\n" +
                "* What does you boss think about you?\n" +
                "\n" +
                "* How is your relation with your co-workers?\n" +
                "\n" +
                "* What challenges do you face in your current job?\n" +
                "\n" +
                "* Tell me about a challenging situation you encountered at work and how you handled it?\n" +
                "\n" +
                "* Where do you see yourself in five years?");
        ten.add("1. Tell me a number of subjects you had in 10th Standard\n" +
                "   Which was your favorite subject?\n" +
                "   Which subject did you not like?\n" +
                "   Who was your favorite teacher?\n" +
                "   Your aggregate marks in 10th class\n" +
                "   What was your routine during 10th class?\n" +
                "   Tell me same things about 12th Class\n" +
                "   Tell me about the institution where you graduated\n" +
                "   Tell me about your graduation years\n" +
                "   Did you give any competitive exams after 12th or graduation? Result?\n" +
                "\n" +
                "\n" +
                "2. Name of the place you come from ?\n" +
                "   Institution where you had your education ?\n" +
                "   Your 10th class marks ?\n" +
                "   Favorite subjects in 10th class?\n" +
                "   Favorite teachers in 10th class, why?\n" +
                "   Teachers you didn’t like in 10th, why?\n" +
                "   Your 12th class marks?\n" +
                "   Favorite subjects in 12th class?\n" +
                "   Favorite teachers in 12th class, why?\n" +
                "   Teachers you didn’t like in 12th, why?\n" +
                "   Any competitive exam after 12th, what was the result?\n" +
                "   Your graduation %age?\n" +
                "   Why did you choose Btech/BSc/etc?\n");

            eleven.add("* What do you know about Indian Army/Air Force/Navy?\n" +
                    "\n" +
                    "* Questions about equivalent ranks from all three forces.\n" +
                    "\n" +
                    "* What will be your contribution to defense after becoming an officer?\n" +
                    "\n" +
                    "* Name four Fighter aircrafts / tanks used by Indian defense?\n" +
                    "\n" +
                    "* What are recent developments in Indian Army/Air Force/Navy?\n" +
                    "\n" +
                    "* What are the differences between a cruiser and a ballistic missile?\n" +
                    "\n" +
                    "* What new Weapons are introduced in Indian Army/Air Force/Navy?\n" +
                    "\n" +
                    "* Which country did India buy those weapons from?\n" +
                    "\n" +
                    "* How is Dassault Rafael deal beneficial to India? \n" +
                    "\n" +
                    "* Some questions related to major wars that India has fought.\n" +
                    "\n" +
                    "* Questions about recent Defence deals.\n" +
                    "\n" +
                    "* Information about a few missiles/aircrafts/guns/weapons/ships.\n");
            twelve.add("Basic Questions in accordance to your stream.");
            thirteen.add("* Which Games do you play?\n" +
                    "\n" +
                    "* Why did you choose to pursue this game?\n" +
                    "\n" +
                    "* How many players are there in a team and substitutes?\n" +
                    "\n" +
                    "* Since when are you playing this game?\n" +
                    "\n" +
                    "* Name some prominent players of the game.\n" +
                    "\n" +
                    "* Which player is your favorite and why?\n" +
                    "\n" +
                    "* Describe 5 fouls in the game.\n" +
                    "\n" +
                    "* What is your position in the game?\n" +
                    "\n" +
                    "* How is your co-ordination with the team?\n" +
                    "\n" +
                    "* Questions about rules of the game to be expected.\n" +
                    "\n" +
                    "* Questions about dimensions of playing area to be expected.\n" +
                    "\n" +
                    "* How would you organize a sport event in your school/college/organization?\n" +
                    "\n" +
                    "* What international championships are held?\n" +
                    "\n" +
                    "* Recent world records and winners.\n");

                    forteen.add("* What if you are not recommended?\n" +
                            "\n" +
                            "* What if you get permanent rejection in medicals?\n" +
                            "\n" +
                            "* If you won a Rs.10-crore lottery, would you still work?\n" +
                            "\n" +
                            "* What are the three things that are most important for you in a job?\n" +
                            "\n" +
                            "* If you are given a chance to change something from your past, what would it be?\n" +
                            "\n" +
                            "* Are you in a relationship? If yes, how intimate? if no, then why? Are you homosexual?\n" +
                            "\n" +
                            "* Why did you opt for the Air Force only? Why not Navy or Army? (or vice versa)\n" +
                            "\n" +
                            "* What if I run away persuading your sister?\n" +
                            "\n" +
                            "* What if one morning you woke up & found that you were pregnant?\n" +
                            "\n" +
                            "* DO you smoke/Drink, why/why not?\n" +
                            "\n" +
                            "* If you commit a crime without anyone seeing you, would you tell anyone about it, who?\n" +
                            "\n" +
                            "* Who would you save in a sinking boat? An old lady or your best friend?\n" +
                            "\n");





        answer.put(question.get(0),one);
        answer.put(question.get(1),two);
        answer.put(question.get(2),three);
        answer.put(question.get(3),four);
        answer.put(question.get(4),five);
        answer.put(question.get(5),six);
        answer.put(question.get(6),seven);
        answer.put(question.get(7),eight);
        answer.put(question.get(8),nine);
        answer.put(question.get(9),ten);
        answer.put(question.get(10),eleven);
        answer.put(question.get(11),twelve);
        answer.put(question.get(12),thirteen);
        answer.put(question.get(13),forteen);




    }



}

