package com.example.ssbcrackpractice;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class wat_three extends AppCompatActivity {
    int count=0;
    String words[]={"sample","Difficult","Decision","Respect","Nation","Peace","Compromise","Challenge","Impossible","Rights","Discipline","Careless","Love","Climb","Life","work","Prosperity","Fight","Mother","Responsible","Team","Danger","Advance","Lead","War","Character","Education","Newspaper","Program","Tiredness","Conference","Correct","Enjoy","Leader","Alert","Method","Defeat","Coward","Governor","Honor","Disturb","Difference","Childhood","Capable","Dream","Divide","Enter","Compile","Fear","Judge","Good","Cruel","Kill","Notice","Girl","Herd","Last","Patriotism","Rule","Inferior"};
    String number[]={"sample","2/60","3/60","4/60","5/60","6/60","7/60","8/60","9/60","10/60","11/60","12/60","13/60","14/60","15/60","16/60","17/60","18/60","19/60","20/60","21/60","22/60","23/60","24/60","25/60","26/60","27/60","28/60","29/60","30/60","31/60","32/60","33/60","34/60","35/60","36/60","37/60","38/60","39/60","40/60","41/60","42/60","43/60","44/60","45/60","46/60","47/60","48/60","49/60","50/60","51/60","52/60","53/60","54/60","55/60","56/60","57/60","58/60","59/60","60/60"};

    Timer t = new Timer();
    public MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wat_three);
        mp = MediaPlayer.create(this, R.raw.camera);

        t.scheduleAtFixedRate(
                new TimerTask() {
                    @Override
                    public void run() {


                        mp.start();


                    }
                }, 0,
                15000);

        final TextView textView=(TextView)findViewById(R.id.textid);
        final TextView textView1=(TextView)findViewById(R.id.watno);


        Thread t=new Thread(){



            @Override
            public void run(){


                while(!isInterrupted()){

                    try {
                        Thread.sleep(15000);  //1000ms = 1 sec

                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                count++;
                                if (count < words.length){

                                    textView.setText(words[count]);
                                    textView1.setText(number[count]);


                                }else{
                                    wat_three.this.finish();
                                }
                            }
                        });

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        };

        t.start();

        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("WAT-3");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
    @Override
    protected void onPause() {
        t.cancel();
        super.onPause();
    }
}
