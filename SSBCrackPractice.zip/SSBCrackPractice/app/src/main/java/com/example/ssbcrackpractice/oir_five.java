package com.example.ssbcrackpractice;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class oir_five extends AppCompatActivity {
    String [][] words=new String[][] {{"  If 'DOWN' is coded as 'FQYP', then how will 'WITH' be coded? " ," If 'CRY' is coded as 'MRYC', then how will 'GET' be coded?" ," Varun drove his car for 80 kms due North. Then he turned left and drove for 100 kms. Again he turned left & drove yet another 80 kms. Again he turned left and drove his car 120 kms. How far do you think he actually drove his car from the initial position?" ," In the evening, Ashmita started walking positioning his back towards the sun. After sometime, she turned left, then turned right and then towards the left again. In which direction is she going now?" ," If A is the brother of B; B is the sister of C; and C is the father of D, how D is related to A?" ," Pointing to a woman, Abhijit said, \" Her granddaughter is the only daughter of my brother.\"  How is the woman related to Abhijit?" ," Choose the odd one out." ," Choose the odd one out." ," Find the next term: 1, 3, 4, 8, 15, 27, ?" ,"  How many times the hands of a clock coincide in a day?" ," What two signs in the following equation need to be interchanged so that the equation will be mathematically correct? 5 + 3 x 8 – 12 ÷4 = 3" ,"  If * stands for 'addition', / stands for 'subtraction', + stands for 'multiplication', and - stands for 'division', then 20 * 8 / 8 - 4 + 2 = ?" ," If - means *, * means +, + means / and / means -, then 40 * 12 + 3 - 6 / 60 = ?" ," Arrange the words given below in a meaningful sequence.\n1. Police\t2. Punishment\t3. Crime\n4. Judge\t5. Judgement" ," Arrange the words given below in a meaningful sequence\n1. Family\t2. Community\t3. Member\n4. Locality\t5. Country" ," Optimist is to cheerful as pessimist is to" ," Reptile is to lizard as flower is to" ," Play is to actor as concert is to" ," Choose the word which is different from the rest." ," Choose the word which is different from the rest." ," Choose the word which is different from the rest." ," Make a meaningful word from 'CEEDIE'" ," By how many degrees does the minute hand move in the same time, in which the hour hand move by 18 degree ?" ," Ashwin introduces Rohit as the son of the only brother of his father’s wife. How is Ashwin’s mother related to Rohit?" ," Choose the word which is least like the other words in the group." ," Pointing to Raja, Rani said, “His mother’s brother is the father of my son Rajkumar”.How is Raja related to Rani?" ," An accurate clock is started at noon. By 10 minutes past 3, the hour hand has turned through:" ," Rearrange to form a meaningful word: 'inrtag'" ," Which is the one that does not belong to the group?" ," Which is the one that does not belong to the group?" ," Complete the Analogy\n BCDE: PQRS :: WXYZ : ?" ," Find a pair that is similar to: 10 : 900" ," Find the missing term in the second group: - BAT: CDY:: BIG : ?" ," Find the missing number\n 1, 8, 27, 64, 125, 216,?" ," Find the missing number \n 23, 29, 31, 37, 41, 43,?" ," Choose the similar analogy\n RIBS : LUNGS" ," Choose the similar analogy\n RAIN : DRIZZLE" ," In a certain coding system TRAIN is written as GIZRM, how will you code FIGURE?" ," Balwant had 17 sheep. A storm in the village killed all but 7 sheep .How many was he left with?" ," A group of 1200 persons consisting of captains and soldiers is travelling in a train For every 15 soldiers there is one captain. The number of captains in the group is" ," Rimmy pulse rate is 19 beats every 15 seconds. What is her rate in beats per minute?" },
            {" YKVJ" ," METG" ," 20 kms" ," North" ," Cannot be determined" ," Mother" ," Fox" ," Sun" ," 50" ," 22" ," ÷and –" ," 24" ," None of these" ," 3, 1, 4, 5, 2" ," 3, 1, 2, 4, 5" ," gloomy" ," daisy" ," musician" ," Swan" ," Sharp" ," Hammer" ," DECIDE" ," 216  degree" ," Aunt" ," Explosion" ," Nephew" ," 95" ," rating" ," Child" ," KLMN" ," 8 : 448" ," CLL" ," 343" ," 47" ," shell : nut" ," run : jog" ," URTFIV" ," 7" ," 75" ," 76" },

            {" Q 1" ," Q 2" ," Q 3" ," Q 4" ," Q 5" ," Q 6" ," Q 7" ," Q 8" ," Q 9" ," Q 10" ," Q 11" ," Q 12" ," Q 13" ," Q 14" ," Q15" ," Q 16" ," Q 17" ," Q 18" ," Q 19" ," Q 20" ," Q 21" ," Q 22" ," Q 23" ," Q 24" ," Q 25" ," Q 26" ," Q 27" ," Q 28" ," Q 29" ," Q 30" ," Q 31" ," Q 32" ," Q 33" ," Q 34" ," Q 35" ," Q 36" ," Q 37" ," Q 38" ," Q 39" ," Q 40" }};

    String [] optionone=new String[] {" KYN" ," MTEG" ," 20 kms" ," North" ," Brother" ," Sister" ," Cat" ," Sun" ," 37" ," 24" ,"  – and +" ,"  80" ,"  7.95" ," 3, 1, 2, 4, 5" ," 3, 1, 2, 4, 5" ," gloomy" ," petal" ," symphony" ," Sparrow" ," Tall" ," Dagger" ," -" ," 168 degree " ," Cousin" ," Volcano" ," Niece" ," 90" ," -" ," Plastic" ," Boy" ," EFGH" ," 6 : 1296" ," CLL" ," 354" ," 53" ," ball : sphere" ," swim :dive" ," USTGKV" ," 10" ," 85" ," 76" };
    String [] optiontwo=new String[] {" JYK" ," MGET" ," 100 kms" ," East" ," Sister" ," Grandmother" ,"  Dog" ," Saturn" ," 44" ," 22" ," x and ÷" ,"  25" ," 16" ," 1, 2, 4, 3, 5" ," 3, 1, 2, 5, 4" ," mean" ," stem" ," musician" ," Swan" ," Huge" ," Hammer" ," -" ," 216  degree" ," Aunt" ," Tsunami" ," Nephew" ," 95" ," -" ," Silk" ," Girl" ," KLMN" ," 2 : 1030" ," DLN" ," 392" ," 47" ," hand : finger" ," run : jog" ," VTYXTC" ," 6" ," 80" ," 60" };
    String [] optionthree=new String[] {" YKVJ" ," MEGT" ," 60 kms" ," West" ," Nephew" ," Mother-in-law" ," Fox" ," Pluto" ," 50" ," 23" ," ÷and –" ," 24" ," 44" ," 5, 4, 3, 2, 1" ," 3, 1, 4, 2, 5" ," petty" ," daisy" ," piano" ," Parrot" ," Thin" ," Knife" ," -" ," 196  degree " ," Uncle" ," Avalanche" ," Aunt" ," 100" ," -" ," Polythene" ," Lady" ," QJSP" ," 8 : 448" ," ANP" ," 343" ," 48" ," shell : nut" ," juggle : bounce" ," URTFIV" ," 7" ," 75" ," 57" };
    String [] optionfour=new String[] {" JKVY" ," METG" ," Can't Say" ," South" ," Cannot be determined" ," Mother" ,"  Rabbit" ,"  Mercury" ," 55" ," 21" ," None of these" ," 5" ," None of these" ," 3, 1, 4, 5, 2" ," 3, 1, 4, 5, 2" ," helpful" ," alligator" ," percussion" ," Koel" ," Sharp" ," Sword" ," -" ," 276 degree" ," Sister" ," Explosion" ," Sister" ," 105" ," -" ," Terelyne" ," Child" ," TSUV" ," 9 : 81" ," CFP" ," 245" ," 59" ," coat : tie" ," walk : run" ," VKGTSV" ," 9" ," 70" ," 45" };
    int counter=0;
    TextView option1;
    TextView option2;
    TextView option3;
    TextView option4;
    TextView tv;
    TextView tvt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oir_five);

        tv=(TextView)findViewById(R.id.tvid);
        tvt=(TextView)findViewById(R.id.tvt);
        Button b1=(Button)findViewById(R.id.ans);
        Button b2=(Button)findViewById(R.id.nex);
        option1=(TextView)findViewById(R.id.op1);
        option2=(TextView)findViewById(R.id.op2);
        option3=(TextView)findViewById(R.id.op3);
        option4=(TextView)findViewById(R.id.op4);



        tv.setText(words[0][counter]);
        tvt.setText(words[2][counter]);
        option1.setText(optionone[counter]);
        option2.setText(optiontwo[counter]);
        option3.setText(optionthree[counter]);
        option4.setText(optionfour[counter]);


        counter=1;

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv.setText(words[0][counter]);
                tvt.setText(words[2][counter]);
                option1.setText(optionone[counter]);
                option2.setText(optiontwo[counter]);
                option3.setText(optionthree[counter]);
                option4.setText(optionfour[counter]);




                if(counter<words[0].length)
                {
                    counter++;
                }
                else
                {
                    finish();
                }

            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast tea= Toast.makeText(oir_five.this,words[1][counter-1],Toast.LENGTH_SHORT);
                tea.show();


            }
        });



        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("OIR-5" );
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

}
