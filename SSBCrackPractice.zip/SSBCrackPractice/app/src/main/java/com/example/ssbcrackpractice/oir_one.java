package com.example.ssbcrackpractice;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class oir_one extends AppCompatActivity {
    String [][] words=new String[][] {{/* questions ->*/" Odometer is to mileage as compass is to "," Marathon is to race as hibernation is to"," Window is to pane as book is to"," Cup is to coffee as bowl is to"," Complete the series :\n 120, 99, 80, 63, 48"," Complete the series :\n 589654237, 89654237, 8965423, 965423"," Choose the pair in which words are differently related from the rest: "," Choose the pair in which words are differently related from the rest: "," Choose the pair in which words are differently related from the rest: "," Choose the pair in which words are differently related from the rest: "," By how many degrees a minute hand rotates in 45 minutes"," Milky Way is galaxy from which we get milk when it rains"," Choose the correct alternative and complete the given series \n 1, 3, 5, 7,_"," If in a certain language, DELHI is coded as EFMIJ, how is BOMBAY coded in that code ?"," Which of the following is always found in Bravery?"," A song always has a..?"," Yesterday, I saw an Ice cube which had already melted due to heat of nearby furnace..?"," Which letter does not belong in the series: \n H, D, R, Y, L"," Which alpha numeric code is odd one out?"," John likes these numbers except one, which one..?"," Arrange the words given in a meaningful sentence: \n 1. Key   2. Door   3. Lock   \n 4. Room   5. Switch on"," Arrange the words given in a meaningful sentence: \n 1. Word   2. Paragraph   3. Sentence   \n 4. Letters    5. Phrase"," Pointing towards a man, a woman said,'His mother is the only daughter of my mother.' How is the woman related to the man?"," Introducing Amir, Manish says 'She is the wife of only nephew of only brother of my mother' How Amir is related to Manish?","Some boys are sitting in three rows all facing North such that A is in the middle row. P is just to the right of A but in the same row. Q is just behind of P while R is in the North of A. In which direction of R is Q?","Ravi left home and cycled 10 km towards South, then turned right and cycled 5 km and then again turned right and cycled 10 km. After this he turned left and cycled 10 km. How many kilometers will he have to cycle to reach his home straight?","If P + Q means P is the brother of Q; P x Q means P is the father of Q and P - Q means P is the sister of Q, which of the following relations shows that I is the niece of K?","Which one of the following is always found in 'Bravery'?","A lotus flower always has","In each word of the following questions consists of pair of words bearing a relationship among these, from amongst the alternatives, pick up the pair that best illustrate a similar relationship.","In each word of the following questions consists of pair of words bearing a relationship among these, from amongst the alternatives, pick up the pair that best illustrate a similar relationship.","Choose the word that is different from the rest.","Choose the word which is different from the rest","All the faces of a cube are painted with blue colour. Then it is cut into 125 small equal cubes. How many small cubes will be formed having no face coloured ?","In three coloured boxes - Red, Green and Blue, 108 balls are placed. There are twice as many balls in the green and red boxes combined as there are in the blue box and twice as many in the blue box as there are in the red box. How many balls are there in the green box ?","Find out which one of the given alternatives will be another member of the group or of that class. \n Wrestling, Karate, Boxing:","'College' is related to 'Teachers' in the same way as 'Hospital' is related to:","Choose the word which is different from the rest.","Choose the word which is different from the rest.","Pick up the pair that best illustrate a similar relationship.\n Border : Country"},/*answers -> */{"direction","sleep","page","soup","35","96542","Boy:Girl","Chisel:Soldier","270 degrees","Absurd","9","CPNCBZ","Courage","Word","Never","Y","8F","6581","1,3,2,4,5","4,1,5,3,2","Mother","Wife","South-East","15 km","K + Y * I -X","courage","Petals","Colour : Faded","Ink : Paper","India","Alzheimer's disease","27","None of these","Judo","Doctors","Rhea","Tendons","Lucknow"},{"Q 1","Q 2","Q 3","Q 4","Q 5","Q 6","Q 7","Q 8","Q 9","Q 10","Q 11","Q 12","Q 13","Q 14","Q15","Q 16","Q 17","Q 18","Q 19","Q 20","Q 21","Q 22","Q 23","Q 24","Q 25","Q 26","Q 27","Q 28","Q 29","Q 30","Q 31","Q 32","Q 33","Q 34","Q 35","Q 36","Q 37","Q 38","Q 39","Q 40"}};
    String [] optionone=new String[] {" speed"," winter"," novel"," dish"," 35"," 58965"," Shirt:Dress"," Scalpel:Surgeon"," Tree:Stem"," Book:Page"," 90 degrees"," True"," 8"," EKNVDQ"," Experience"," Word"," Always"," H"," 8F"," 8656"," 5,1,2,4,3"," 4,1,5,2,3"," Mother"," Wife"," South"," 10 km"," K + Y + Z - I"," Experience"," Mud"," Moisture : Humid"," Type : Point"," Japan"," Kleptomania"," 27"," 18"," Pole-vault"," Doctors"," Rhea"," Spine"," Pen : Cap"," Daman"};
    String [] optiontwo=new String[] {" hiking"," bear"," glass"," soup"," 38"," 65423"," Boy:Girl"," Chisel:Soldier"," Face:Eye"," Table:Drawer"," 180 degrees"," False"," 9"," GMPVDS"," Power"," Chorus"," Never"," R"," 3E"," 7243"," 4,2,1,5,3"," 4,1,3,5,2"," Grandmother"," Sister"," South-West"," 15 km"," K + Y * I - Z"," Power"," Petals"," Colour : Faded"," Table : Chair"," India"," Schizophrenia"," 8"," 36"," Swimming"," Patients"," Trout"," Ribs"," Book : Cover"," Pondicherry"};
    String [] optionthree=new String[] {" needle"," dream"," cover"," spoon"," 39"," 89654"," Mango:Fruit"," Awl:Cobbler"," Chair:Sofa"," Loom:Cloth"," 270 degrees"," Probable"," 10"," CPNCBZ"," Courage"," Musician"," Often"," Y"," 9D"," 6581"," 1,3,2,4,5"," 4,2,5,1,3"," Sister"," Sister in law"," North-East"," 20 km"," Z - I * Y +K"," Courage"," Root"," Despair : Anger"," Door : Handle"," Sri Lanka"," Agoraphobia"," 16"," 45"," Judo"," Medicines"," Lamprey"," Femur"," Handle : Shade"," Chandigarh"};
    String [] optionfour=new String[] {" direction"," sleep"," page"," food"," 40"," 96542"," Table:Furniture"," Knife:Chef"," Plant:Flower"," Car:Wheel"," 45 degrees"," Absurd"," 11"," HNQYGT"," Knowledge"," Tymbal"," Sometimes"," L"," 6C"," 1431"," 1,2,3,5,4"," 4,1,5,3,2"," Daughter"," Data inadequate"," South-East"," 25 km"," K * Y + I - Z"," Knowledge"," Water"," Odour : Pungent"," Ink : Paper"," New Zealand"," Alzheimer's disease"," 24"," None of these"," Polo"," Beds"," Salmon"," Tendons"," Frame : Picture"," Lucknow"};
    int counter=0;
    TextView option1;
    TextView option2;
    TextView option3;
    TextView option4;
    TextView tv;
    TextView tvt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oir_one);

        tv=(TextView)findViewById(R.id.tvid);
        tvt=(TextView)findViewById(R.id.tvt);
        Button b1=(Button)findViewById(R.id.ans);
        Button b2=(Button)findViewById(R.id.nex);
        option1=(TextView)findViewById(R.id.op1);
        option2=(TextView)findViewById(R.id.op2);
        option3=(TextView)findViewById(R.id.op3);
        option4=(TextView)findViewById(R.id.op4);



        tv.setText(words[0][counter]);
        tvt.setText(words[2][counter]);
        option1.setText(optionone[counter]);
        option2.setText(optiontwo[counter]);
        option3.setText(optionthree[counter]);
        option4.setText(optionfour[counter]);


        counter=1;

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv.setText(words[0][counter]);
                tvt.setText(words[2][counter]);
                option1.setText(optionone[counter]);
                option2.setText(optiontwo[counter]);
                option3.setText(optionthree[counter]);
                option4.setText(optionfour[counter]);




                if(counter<words[0].length)
                {
                    counter++;
                }
                else
                {
                    finish();
                }

            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast tea= Toast.makeText(oir_one.this,words[1][counter-1],Toast.LENGTH_SHORT);
                tea.show();


            }
        });



        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("OIR-1");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

}
