package com.example.ssbcrackpractice;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class oir_two extends AppCompatActivity {
    String [][] words=new String[][] {{/* questions ->*/"Aruna cut a cake into two halves and cuts one half into smaller pieces of equal size. Each of the small pieces is twenty grams in weight. If she has seven pieces of the cake in all with her, how heavy was the original cake ?"," P started from his house towards west. After walking a distance of 25 m. He turned to the right and walked 10 m.He then again turned to the right and walked 15 m. After this he is to turn right at 135o and to cover 30 m. In which direction should he go?"," One day at 2 P.M. Manisha and Madhuri were talking to each other face to face. If Manisha's shadow was exactly to the left of Madhuri, which direction Manisha was facing?"," Veena who is the sister-in-law of Ashok, is the daughter-in-law of Kalyani. Dheeraj is the father of Sudeep who is the only brother of Ashok. How Kalyani is related to Ashok?"," A's son B is married with C whose sister D is married to E the brother of B. How D is related to A"," A boy is sitting at the back seat of a car. When the driver suddenly starts moving the car (in forward direction), the boy experiences a backward force?"," In each of the following questions find out the alternative which will replace the question mark.\n Safe : Secure :: Protect : ? "," Ice : Coldness :: Earth : ?"," Computer : fqprxvht :: Language : ? "," ? : QEHMDF :: WIDELY : HVCDXK "," 68 : 130 :: ? : 350"," Pick up the pair that best illustrate a similar relationship.\n Numismatist : Coins"," One morning after sunrise, Vimal started to walk. During this walking he met Stephen who was coming from opposite direction. Vimal watch that the shadow of Stephen to the right of him (Vimal). To Which direction Vimal was facing?"," After walking 6 km, I turned to the right and then walked 2 km. After then I turned to the left and walked 10 km. In the end, I was moving towards the North. From which direction did I start my journey?"," If X + Y means X is the daughter of Y; X - Y means X is the brother of Y; X % Y means X is the father of Y and X x Y means X is the sister of Y. Which of the following means I is the niece of J?"," In each of the following questions find out the alternative which will replace the question mark.\n BLOCKED : YOLXPVW :: ? : OZFMXS"," Find out which one of the given alternatives will be another member of the group or of that class.\n Root, Stem, Branch"," 'Forest' is related to 'Vivarium' in the same way as 'sea' is related to:"," Arrange the words given below in a meaningful sequence.\n 1. Elephant\t2. Cat\t3. Mosquito \n 4. Tiger\t5. Whale"," Rohit walked 25 m towards south. Then he turned to his left and walked 20 m. He then turned to his left and walked 25 m. He again turned to his right and walked 15 m. At what distance is he from the starting point and in which direction?"," If A + B means A is the mother of B; A - B means A is the brother B; A % B means A is the father of B and A x B means A is the sister of B, which of the following shows that P is the maternal uncle of Q?"," If P $ Q means P is the brother of Q; P # Q means P is the mother of Q; P * Q means P is the daughter of Q in A # B $ C * D, who is the father?"," If M x N means M is the daughter of N; M + N means M is the father of N; M % N means M is the mother of N and M - N means M is the brother of N then P % Q + R - T x K indicates which relation of P to K?"," Which one of the following a 'Drama' must have?"," A car always has "," Arrange the words given below in a meaningful sequence\n 1. Leaves\t2. Branch\t3. Flower\n 4. Tree\t5. Fruit"," Controversy always involves","KeaC : CaeK :: XgmF : ?","CEDH : HDEC :: ? : PNRV","CEDH : HDEC :: ? : PNRV"," PSQR : CFED :: JMKL : ?","ABCD : WXYZ :: EFGH : ?","Pick up the pair that best illustrate a similar relationship.\n Stove : Kitchen"," Find out which one of the given alternatives will be another member of the group or of that class.\n Lock, Shut, Fasten"," Find out which one of the given alternatives will be another member of the group or of that class.\n Clutch, Brake, Horn"," 'Smoke' is related to 'Pollution' in the same way as 'War' is related to:","Arrange the words given below in a meaningful sequence. \n 1. Nation\t2. Village\t3. City \n 4. District\t5. State","Village Q is to the North of the village P. The village R is in the East of Village Q. The village S is to the left of the village P. In which direction is the village S with respect to village R?","Sachin walks 20 km towards North. He turns left and walks 40 km. He again turns left and walks 20 km. Finally he moves 20 km after turning to the left. How far is he from his starting position?","Pointing towards a man, a woman said, 'His mother is the only daughter of my mother.' How is the woman related to the man? ","A song always has ","Which one of the following is always with 'Bargain'?"},
            /*answers -> */{"240 grams","South-West","None of these","Daughter's-in-law"," Always"," Guard","Gravitatism","ocqixcjg","FRINGE","222","Philatelist : Stamps","South","South","I x C + N - J","LAUNCH","Leaf","Aquarium","3, 2, 4, 1, 5","35 m East","P - M + N x Q","D","None of these","Story","Wheels","4, 2, 1, 3, 5","Disagreement","FmgX","VRNP ","WZYX","STUV","Television : Living room","Block","Steering","Destruction","2, 3, 4, 5, 1","South-West","20 km","Mother","Word"},{"Q 1","Q 2","Q 3","Q 4","Q 5","Q 6","Q 7","Q 8","Q 9","Q 10","Q 11","Q 12","Q 13","Q 14","Q15","Q 16","Q 17","Q 18","Q 19","Q 20","Q 21","Q 22","Q 23","Q 24","Q 25","Q 26","Q 27","Q 28","Q 29","Q 30","Q 31","Q 32","Q 33","Q 34","Q 35","Q 36","Q 37","Q 38","Q 39","Q 40"}};




    String [] optionone=new String[] {" 120 grams"," West"," East"," Mother-in-law"," Sister"," Always"," Lock"," Weight"," oxpixdig"," FRINGE"," 220"," Jeweller : Jewels"," East"," North"," J - N % C x I"," DEBATE"," Fertilizer"," Port site"," 5, 3, 1, 2, 4"," 35 m East"," Q - N + M x P"," D"," Daughter-in-law"," Actors"," Driver"," 4, 3, 1, 2, 5"," Dislike"," GmcF"," VRNP"," UVXZ"," STUV "," Window : Bedroom"," Window"," Car"," Victory"," 2, 3, 4, 5, 1"," West"," 20 km"," Mother"," Word"," Exchange"};

    String [] optiontwo=new String[] {" 140 grams"," South"," West"," Aunt"," Daughter's-in-law"," Never"," Sure"," Jungle"," ocqicyig"," STRING"," 224"," Cartographer : Maps"," West"," South"," I x C - N % J"," RESULT"," Leaf"," Water"," 3, 2, 4, 1, 5"," 35 m North"," P + S x N - Q"," B"," Sister-in-law"," Story"," Wheels"," 4, 2, 5, 1, 3"," Injustice"," FmgX"," RNPV"," YVZX"," ZYXW"," Sink : Bathroom"," Door"," Scooter"," Treaty"," 2, 3, 4, 1, 5"," South-West"," 30 km"," Grandmother"," Chorus"," Sumptuousness"};

    String [] optionthree=new String[] {" 240 grams"," South-West"," North"," Wife"," Sister-in-law"," Often"," Guard"," Gravitatism"," ocqixcjg"," FRANCE"," 222"," Philatelist : Stamps"," South"," East"," J + M x C % I"," LABOR"," Tree"," Fishery"," 1, 3, 5, 4, 2"," 30 m West"," P - M + N x Q"," C"," Aunt"," Sets"," Bonnet"," 4, 3, 2, 1, 5"," Disagreement"," EgmX"," NRVP"," YXZW"," VUTS"," Pot : Pan"," Iron"," Accident"," Defeat"," 1, 3, 5, 4, 2"," South"," 50 km"," Sister"," Musician"," Triviality"};

    String [] optionfour=new String[] {" 280 grams"," South-East"," South"," None of these"," Cousin"," Sometimes"," Conserve"," Sea"," ocqixcig"," DEMAND"," 226"," Geneticist : Chromosomes"," Data inadequate"," West"," I x C + N - J"," LAUNCH"," Wood"," Aquarium"," 2, 5, 1, 4, 3"," 45 m East"," Q - S % P"," Data is inadequate"," None of these"," Director"," Bumper"," 4, 2, 1, 3, 5"," Passion"," EmgF"," VNRP"," WZYX"," WXZY"," Television : Living room"," Block"," Steering"," Destruction"," 1, 2, 3, 4, 5"," North-West"," 60 km"," Daughter"," Tymbal"," Eloquence"};
    int counter=0;
    TextView option1;
    TextView option2;
    TextView option3;
    TextView option4;
    TextView tv;
    TextView tvt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oir_two);

        tv=(TextView)findViewById(R.id.tvid);
        tvt=(TextView)findViewById(R.id.tvt);
        Button b1=(Button)findViewById(R.id.ans);
        Button b2=(Button)findViewById(R.id.nex);
        option1=(TextView)findViewById(R.id.op1);
        option2=(TextView)findViewById(R.id.op2);
        option3=(TextView)findViewById(R.id.op3);
        option4=(TextView)findViewById(R.id.op4);



        tv.setText(words[0][counter]);
        tvt.setText(words[2][counter]);
        option1.setText(optionone[counter]);
        option2.setText(optiontwo[counter]);
        option3.setText(optionthree[counter]);
        option4.setText(optionfour[counter]);


        counter=1;

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv.setText(words[0][counter]);
                tvt.setText(words[2][counter]);
                option1.setText(optionone[counter]);
                option2.setText(optiontwo[counter]);
                option3.setText(optionthree[counter]);
                option4.setText(optionfour[counter]);




                if(counter<words[0].length)
                {
                    counter++;
                }
                else
                {
                    finish();
                }

            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast tea= Toast.makeText(oir_two.this,words[1][counter-1],Toast.LENGTH_SHORT);
                tea.show();


            }
        });



        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("OIR-2");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

}
