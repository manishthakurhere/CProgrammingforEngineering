package com.example.ssbcrackpractice;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.PowerManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewFlipper;

import java.util.Timer;
import java.util.TimerTask;

public class tat_eight extends AppCompatActivity {
    protected PowerManager.WakeLock mWakeLock;
    int count=0;
    int images[] = {R.drawable.toone,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.totwo,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tothree,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tofour,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tofive,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tosix,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.toseven,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.toeight,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tonine,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.toten,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.toeleven,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.blankslide,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback};
    String number[]={"sample","2/12","3/12","4/12","5/12","6/12","7/12","8/12","9/12","10/12","11/12","12/12"};

    ViewFlipper flipper;
    Timer t = new Timer();
    public MediaPlayer mp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //prevent screen from sleeping
        final PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        this.mWakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "SSB:TAG");
        this.mWakeLock.acquire();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tat_eight);



        mp = MediaPlayer.create(this, R.raw.camera);

        int images[] = {R.drawable.toone,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.totwo,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tothree,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tofour,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tofive,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tosix,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.toseven,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.toeight,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tonine,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.toten,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.toeleven,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.blankslide,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback};
        flipper = findViewById(R.id.flipper2);

        t.scheduleAtFixedRate(
                new TimerTask() {
                    @Override
                    public void run() {

                        mp.start();
                    }
                }, 0,
                270000);


        for (int i = 0; i < 108; i++) {
            flipperImages(images[i]);

        }
        final TextView textView=(TextView)findViewById(R.id.tatno);

        Thread t=new Thread(){



            @Override
            public void run(){


                while(!isInterrupted()){

                    try {
                        Thread.sleep(270000);  //1000ms = 1 sec i.e. 4:30 seconds

                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                count++;
                                if (count <number.length){

                                    textView.setText(number[count]);


                                }else{
                                    tat_eight.this.finish();
                                }
                            }
                        });

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        };

        t.start();


        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("TAT-8");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }


    public void flipperImages(int image) {
        ImageView imageView = new ImageView(this);
        imageView.setBackgroundResource(image);

        flipper.addView(imageView);
        flipper.setFlipInterval(30000);
        flipper.setAutoStart(true);

    }


    @Override
    protected void onPause() {
        t.cancel();
        super.onPause();
    }
    @Override
    public void onDestroy() {
        this.mWakeLock.release();
        super.onDestroy();
    }

}



