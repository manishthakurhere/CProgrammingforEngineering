package com.example.ssbcrackpractice;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class srt_one extends AppCompatActivity {
    int count=0;
    String words[]={"sample","His fact friend has got into bad company. He…","When offered something to eat, he declines to take because…","His friend points out his shortcomings. He…","He was about to loose a point in a discussion. He…","His teacher is unable to solve a mathematical sum in the class. He…","When he returned, the river was in full spate, but he had to go to his home urgently. He…","He see his enemy’s son drowning in the river. He…"," His father is transferred to another place. He is happy because…","In a monthly meeting of the colony he is asked to address the meeting extempore on various problems facing the colony. He…","In his college he is offered the hero in a play which is later changed to the role of the villain. He…"," He is visited by an angel in his dream who asked him to make three wishes. He…"," He wins Rs. 2 lacs in a lottery. He…"," He is in a lift with a pretty girl friend when the electricity fails. He…","He appeared before the Service Selection Board but failed to be selected. He…","He looses his brother-in-law in a accident when he was with him on a motor bike. He…","In the last show of a famous and new film he finds that the House Full board is on. He…","In an examination hall, he reaches five minutes late. He…","You are required to dig trenches, but your colleagues are not co-operating with you. He…","While working in the kitchen garden, rain starts. He…","He is assigned a difficult task which he has not done earlier. He…"," As a secretary of Student Union of his college. He will do the following…"," Which returning from market, three persons with knife stop him and ask him to handover his valuable possessions. He…","While patrolling at unit man gate, a terrorist fired at his leg and bleeding started badly and he is snatching his rifle. He…","While on leave he heard radio and announcement about outbreak of WAR. He…","In field area, he was short of manpower; one of his jawans asks for the leave on wrong excuse which he knows is false. He…","He is already late to complete his task. His colleges refund to co-operate with him. He…","While returning from picnic, it starts getting dark and he has lost his way. He…","When his Boss does not agree with his views. He…","He considers that the most important thing in the world is…","While travelling in a train, he came to know that someone has picked his pocket. He…"," Due to financial difficulties, his parents find it difficult to give him further education. He…","While he is waiting for a bus, an accident took place in front him. He…","He went on a mountain expedition which was a failure and of your friends died in the attempt. He…","He felt that the work he is presently engaged is useless. He…","His friend lost his job and into financial difficulties. He…","On finding that you are loosing the ground in a discussion with your opponent. He…"," In his office staff is not working efficiently. He…","He finds a task which is difficult. He","His plan had failed in the very beginning. He…","He is at home and dacoits have reached at his apartment and started looting. He…"," He is asked to organize a variety show in the aid of jawan Welfare in his unit. He…"," His Coy is camping in a jungle for training where shooting is prohibited. A leopard which may prove a dangerous is seen close to the camp as a sentry on duty. He…","Emergency has declared in the city where his unit is located. He is the CO of the unit. He…","Whenever he is required to take new step. He…","While going to the office, he saw a man climbing on a house with the help of a rope. He…"," He has to take group of all India tour. He…",". He hears a cry of fire-fire from neighboring house. He…","He had a minor scooter accident on his way to office in which his scooter got slightly damaged. He…","He has lot his way in the jungle. He","While travelling in a train, he found that his ticket is lost. He…","He is travelling in a bus which suddenly caught fire. He…"," He is come to his home after meeting a friend. Suddenly he has been attacked by some miscreants with lathi. He…","He is passing by a lake, he notices a boy drowning in the water and he does not know swimming. He…","He is passing by a Railway line and saw that the fish plates have been removed. Only 15 minutes are left for the train to reach and the Station is 1.5 kms. away from the spot. He…","He is going to attend the SSB. When the train moves, lady falls down on the platform. He…","He is on annual leave at his village. One day the dacoits started looting his village and also killed a villager. He…"," On his way, he saw a man suddenly falling down on the road. On reaching him he comes to know that he is heart patient. He…","He is travelling in a train. At one of the stations he came down to buy some fruits and when he turned back, the train had already left. He…"," He has to organize a debate competition. He…"};
    String number[]={"sample","2/60","3/60","4/60","5/60","6/60","7/60","8/60","9/60","10/60","11/60","12/60","13/60","14/60","15/60","16/60","17/60","18/60","19/60","20/60","21/60","22/60","23/60","24/60","25/60","26/60","27/60","28/60","29/60","30/60","31/60","32/60","33/60","34/60","35/60","36/60","37/60","38/60","39/60","40/60","41/60","42/60","43/60","44/60","45/60","46/60","47/60","48/60","49/60","50/60","51/60","52/60","53/60","54/60","55/60","56/60","57/60","58/60","59/60","60/60"};

    Timer t = new Timer();
    public MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_srt_one);
        mp = MediaPlayer.create(this, R.raw.camera);

        t.scheduleAtFixedRate(
                new TimerTask() {
                    @Override
                    public void run() {


                        mp.start();


                    }
                }, 0,
                30000);

        final TextView textView=(TextView)findViewById(R.id.textid);
        final TextView textView1=(TextView)findViewById(R.id.srtno);

        Thread t=new Thread(){



            @Override
            public void run(){


                while(!isInterrupted()){

                    try {
                        Thread.sleep(30000);  //1000ms = 1 sec

                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                count++;
                                if (count < words.length){

                                    textView.setText(words[count]);
                                    textView1.setText(number[count]);

                                }else{
                                    srt_one.this.finish();
                                }
                            }
                        });

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        };

        t.start();

        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("SRT-1");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
    @Override
    protected void onPause() {
        t.cancel();
        super.onPause();
    }
}
