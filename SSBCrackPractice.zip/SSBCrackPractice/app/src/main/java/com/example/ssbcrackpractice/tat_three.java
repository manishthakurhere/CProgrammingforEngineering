package com.example.ssbcrackpractice;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.PowerManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewFlipper;

import java.util.Timer;
import java.util.TimerTask;

public class tat_three extends AppCompatActivity {
    protected PowerManager.WakeLock mWakeLock;
    int count=0;
    int images[] = {R.drawable.tone,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.ttwo,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tthree,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tfour,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tfive,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tsix,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.bseven,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.beight,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.bnine,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.bten,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.beleven,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.blankslide,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback};
    String number[]={"sample","2/12","3/12","4/12","5/12","6/12","7/12","8/12","9/12","10/12","11/12","12/12"};

    ViewFlipper flipper;
    Timer t = new Timer();
    public MediaPlayer mp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //prevent screen from sleeping
        final PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        this.mWakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "SSB:TAG");
        this.mWakeLock.acquire();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tat_three);



        mp = MediaPlayer.create(this, R.raw.camera);

        int images[] = {R.drawable.tone,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.ttwo,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tthree,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tfour,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tfive,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tsix,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.bseven,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.beight,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.bnine,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.bten,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.beleven,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.blankslide,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback,R.drawable.tatback};
        flipper = findViewById(R.id.flipper2);

        t.scheduleAtFixedRate(
                new TimerTask() {
                    @Override
                    public void run() {

                        mp.start();
                    }
                }, 0,
                270000);


        for (int i = 0; i < 108; i++) {
            flipperImages(images[i]);

        }
        final TextView textView=(TextView)findViewById(R.id.tatno);

        Thread t=new Thread(){



            @Override
            public void run(){


                while(!isInterrupted()){

                    try {
                        Thread.sleep(270000);  //1000ms = 1 sec i.e. 4:30 seconds

                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                count++;
                                if (count <number.length){

                                    textView.setText(number[count]);


                                }else{
                                    tat_three.this.finish();
                                }
                            }
                        });

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        };

        t.start();


        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("TAT-3");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    public void flipperImages(int image) {
        ImageView imageView = new ImageView(this);
        imageView.setBackgroundResource(image);

        flipper.addView(imageView);
        flipper.setFlipInterval(30000);
        flipper.setAutoStart(true);

    }


    @Override
    protected void onPause() {
        t.cancel();
        super.onPause();
    }
    @Override
    public void onDestroy() {
        this.mWakeLock.release();
        super.onDestroy();
    }

}



