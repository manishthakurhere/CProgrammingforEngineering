package com.example.ssbcrackpractice;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class srt_six extends AppCompatActivity {
    int count=0;
    String words[]={"sample","Due to cyclone his family lost all their possession and needed a fresh start. As the eldest son he... ","On your 1st visit to a snow bound area you saw a man being buried under snow. You ..."," You were not a good swimmer, still being persuaded by your friend you go for swimming in river. You stayed in shallow water your friend went mid stream and suddenly got caught in whirlpool. You..","The sea was very rough and it was night. Ship duty officer fell in sea while taking a round. What you do...","Some people tried to harass his mother. So he...."," During blackout exercises, you were scout on duty. But one rich man was adamant on keeping his lights on, you...","His father needed treatment and he was short of money. He....","You had gone hunting with your friends. They were in forest and they could not be traced. You....","He feels unhappy when...","While choosing his life partner, his criteria of selection will be..","You feel that world can move towards peace if...","He thinks that he is more intelligent. Give reasons...","He lost election. Why...","In order to produce better results in his organization what measures he should take.....","He desires to make national plans a great success for nation what should he do...","In order to help poor he has keen desire. To have good collection of money, what he should do...","You are college cricket team captain. The opening batsman is the brother of the college goon. He’s not been performing. You have the option of dropping him for the time being and getting a substitute. You...","You are walking down the road one fine afternoon and a man steals a lady's hand bag and in the process stabs the lady. You...","You are going to market with your sister and some boys start doing mischief with her. You...","You are a team leader while on a rock climbing expedition. While you are on pick on of your mates slips his hand and falls down. You...","Working under two commanding officers which are passing conflicting orders then what will you do....?","He is sitting on chair studying, there’s a snake right behind his chair and he suddenly looks back. He...","He cracked a joke on one of his friends and his friend got angry so he...","He is studying for final year exam in night. He saw two masked persons entering the neighbors’ house. He...","He and his friends are standing in doorway of train. As the train starts, a friend falls off. He...","Some people are abusing his old mother. He...","He is new in Ngaland. He gets lost in a jungle and sees armed Nagas, he...","He lost his purse in train compartment, he...","Epidemic is broken in his village and people have started moving out of their houses, he...","He and his friends are travelling from a speedy train when his friend looks out of window and gets hit by a pole. He...","While climbing an ice covered mountain, the leader decides to take steep climb and a friend falls in a ditch.","He is new in town and doesn’t know the local language,","His money is lost and he is new in town. He...","His professor asked him to arrange for a picnic.He..","They are climbing a steep wall with help of ropes and some of them reach the top, when the rope gives away, He...","He is forced to vote for a candidate not of his choice.He...","He is a student of final year and his father expires. Uncle throws him out of the house. He...","The leader of his trekking team decides to take a longer route when time is running out, he...","In his train compartment, two gunmen force passengers to give their belongings. He...","He is travelling in train and he lost his money. He...","They decide to give a treat to their retiring professor. He wants to give a dinner party whiles his friends want just a tea‐party. He...","Exams are coming near and he falls seriously ill,he...","He and his father were going on a scooter when they met with an accident. Both of them get hurt but his father is severely injured and on calling for help no turns up, he...","He works too hard in his family but also wants to study further. He...","On a ship doing his duty, he sees fumes and smoke coming out of a cabin. He...","He is a prefect in his hostel. He notices two of his friends bunking, he...","He was forced to join the Railways but he was really not interested. He...","He saw a truck hit a cyclist on highway, he...","All his family members are ill and hisfather is out of town. There is no money in the home. He...","He doesn’t find a subject interesting to study so he...","On opening the door of his bathroom in his room he finds a big snake hanging from the ceiling. He...","Young men are not interested in joining defense forces. What incentive would you offer to lure them?","You are moving along with a convoy to forward area and sitting at the back of the vehicle. You saw a flag car is speeding fast. What will u do...","An airplane crashed in a field nearby your battalion area. You are battalion commander. What steps would you take at such a critical juncture...","He was watching a movie in the cinema hall. He sees a snake in front of his legs. He.....","You are a handsome, smart and brave young ‘army officer'. You fall in love with the girl of another community. But your parents oppose the proposal. You...","What if you and your friend fall in love with the same girl...","You heard rumors that enemy is likely to attack the country. As a serving soldier what u do...","Whenever your opinion differs from others. You...."};
    String number[]={"sample","2/60","3/60","4/60","5/60","6/60","7/60","8/60","9/60","10/60","11/60","12/60","13/60","14/60","15/60","16/60","17/60","18/60","19/60","20/60","21/60","22/60","23/60","24/60","25/60","26/60","27/60","28/60","29/60","30/60","31/60","32/60","33/60","34/60","35/60","36/60","37/60","38/60","39/60","40/60","41/60","42/60","43/60","44/60","45/60","46/60","47/60","48/60","49/60","50/60","51/60","52/60","53/60","54/60","55/60","56/60","57/60","58/60","59/60","60/60"};

    Timer t = new Timer();
    public MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_srt_six);
        mp = MediaPlayer.create(this, R.raw.camera);

        t.scheduleAtFixedRate(
                new TimerTask() {
                    @Override
                    public void run() {


                        mp.start();


                    }
                }, 0,
                30000);

        final TextView textView=(TextView)findViewById(R.id.textid);
        final TextView textView1=(TextView)findViewById(R.id.srtno);

        Thread t=new Thread(){



            @Override
            public void run(){


                while(!isInterrupted()){

                    try {
                        Thread.sleep(30000);  //1000ms = 1 sec

                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                count++;
                                if (count < words.length){

                                    textView.setText(words[count]);
                                    textView1.setText(number[count]);

                                }else{
                                    srt_six.this.finish();
                                }
                            }
                        });

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        };

        t.start();

        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("SRT-6");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
    @Override
    protected void onPause() {
        t.cancel();
        super.onPause();
    }
}
