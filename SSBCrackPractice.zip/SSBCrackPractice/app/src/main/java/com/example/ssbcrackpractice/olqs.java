package com.example.ssbcrackpractice;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class olqs extends AppCompatActivity {
    ExpandableListView expandableListView;

    List<String> question;
    Map<String,List<String>> answer;
    ExpandableListAdapter listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_olqs);

        expandableListView = (ExpandableListView)findViewById(R.id.expandableListView);
        fillData();

        listAdapter=new MyexListadapter(this,question,answer);
        expandableListView.setAdapter(listAdapter);


        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {



                return true;
            }
        });

        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("OLQs");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
    public void fillData()
    {
        question=new ArrayList<>();
        answer = new HashMap<>();



        question.add("* The SSB interview, comprises of three techniques where each technique tries to draw the personality traits of a candidate.A candidate might not have all the 15 OLQs that the assessors seek, but must have the potential to develop them.\n\n* Following is a list of the 15 OLQs that assessors seek and before going to SSB, one must introspect and try to inculcate these qualities. This is not something that can be developed overnight and needs to be put into daily life routine.");
        question.add("1: EFFECTIVE INTELLIGENCE");
        question.add("2: REASONING ABILITY");
        question.add("3: ORGANIZING ABILITY");
        question.add("4: POWER OF EXPRESSION");
        question.add("5: SOCIAL ADAPTABILITY");
        question.add("6: COOPERATION");
        question.add("7: SENSE OF RESPONSIBILITY");
        question.add("8: ABILITY TO TAKE INITIATIVE");
        question.add("9: SELF CONFIDENCE");
        question.add("10: SPEED OF DECISION MAKING");
        question.add("11: INFLUENCING ABILITY");
        question.add("12: LIVELINESS");
        question.add("13: DETERMINATION");
        question.add("14: COURAGE");
        question.add("15: STAMINA");





        List<String> one = new ArrayList<>();
        List<String> two= new ArrayList<>();
        List<String> three= new ArrayList<>();
        List<String> four= new ArrayList<>();
        List<String> five= new ArrayList<>();
        List<String> six= new ArrayList<>();
        List<String> seven= new ArrayList<>();
        List<String> eight= new ArrayList<>();
        List<String> nine= new ArrayList<>();
        List<String> ten= new ArrayList<>();
        List<String> eleven= new ArrayList<>();
        List<String> twelve= new ArrayList<>();
        List<String> thirteen= new ArrayList<>();
        List<String> forteen= new ArrayList<>();
        List<String> fifteen= new ArrayList<>();
        List<String> sixteen= new ArrayList<>();






        two.add("* An officer deals with many practical problems and should be able to handle them without giving in to pressure.\n\n" +
                "* This is the ability of a candidate to deal with practical and real life solutions.\n\n" +
                "* Candidates with good effective intelligence perform well in GTO tasks and give creative and innovative ideas.");


        three.add("* An officer must be apt of rational and logical Thinking.\n\n" +
                "* This is the ability to percieve problems effectively, approach the problem from different angles and come to logically sound solutions.\n\n" +
                "* This is tested in Officer Intelligence Rating Tests.\n\n" +
                "* Candidates with higher aptitude generally perform well in these tests.");

        four.add("* An officer should be able to organize resources so as to utilize them to their maximum potential.\n\n" +
                "* This is the ability to organize and arrange resources and should be practised in day to day life.\n\n" +
                "* This is tested in GTO , mainly in Command Task.\n\n");

        five.add("* An officer must be able to express his ideas and opinions effectively.\n\n" +
                "* This is the ability of a candidate to put forth his/her ideas.\n\n" +
                "* An idea would be rendered useless if it cannot be explained to the team, thus good expressing power is a must.\n\n" +
                "* This is generally tested in Group Discussions and Lecturette.");
        six.add("* An officer is often required to go to different places and interact with different people, thus an officer must be able to easily adapt to different surroundings.\n\n" +
                "* This is the ability of a candidate to adapt to different surroundings, interact effectively with people and make friends.\n\n" +
                "* All group tasks revolve around this quality of the candidate and behavior of the group towards the candidate largely depends on this.\n\n");

        seven.add("* An officer is often required to work as a team, thus an officer must be cooperative as cooperation is the key to work effectively as a team.\n\n" +
                "* This is the ability of a candidate to work in harmony with the group. \n\n" +
                "* All group tasks require cooperation which eventually lead to better results.");

        eight.add("* An officer carries a lot of responsibilities on his shoulders, a leader must be responsible and must stand up to all his/her responsibilities.He/she must have a sense of duty and must stand responsible for his/her actions.\n\n" +
                "* This is the ability of a candidate to take up responsibility voluntarily and stand up to them.\n\n" +
                "* This can be inculcated in personality by trying to take up small scale responsibilities in day to day life.");

        nine.add("* An officer has to lead men and is responsible for taking initiative to lead by example.\n\n" +
                "* This is the ability of a candidate to take initiative towards a purposeful action, and strive to excel.\n\n" +
                "* This is tested in most group activities where one of the group members is supposed to initiate, like initiating a Group Discussion.");

        ten.add("* An officer is often supposed to take decisions and act in stressful and unfamiliar situations. In such situations, it is important to have confidence over oneself.\n\n" +
                "* This is the ability of a candidate to commit to rational and well thought decisions confidently.\n\n" +
                "* Confidence is the key for taking risky decisions for personal and professional growth.\n\n");

        eleven.add("* An officer is often required to take important decisions under pressure quickly. An officer takes practical and affordable decisions within short time span.\n\n" +
                "* This is the ability of a candidate to think critically and quickly to arrive at workable solutions an decisions.\n\n" +
                "* Good observation, optimum utilization of resources and critical thinking are keys to effective decision making.");

        twelve.add("* An officer often works in a team where different people may have different opinions. An officer is required to influence them and win their will to work towards his/her idea.\n\n" +
                "* This is the ability of the candidate to influence the group and win their will to work according to his/her idea.\n\n" +
                "* Almost all group tasks like PGT,HGT,FGT,GD focus on this quality.");

        thirteen.add("* An officer is the one that men look up to for motivation thus an officer must himself/herself be a dynamic and happy going personality no matter the circumstances.\n\n" +
                "* This is the ability of a candidate to stay cheerful in all situations and not lose calm under stress.\n\n" +
                "* A person who is generally cheerful in day to day life does not need any special preparation for this quality.");

        forteen.add("* An officer is a determined person who strives to excel and is never brought down by any onstacle or set back.\n\n" +
                "* This is the ability of a candidate to keep going and never stopping once decided. \n\n" +
                "* This is observed in various tasks like Individual Obstacles.");

        fifteen.add("* An officer is often under adverse situations where he/she might face several dangers. Here he/she might have to show courage and may also involve taking risks. \n\n" +
                "* This is the ability of a candidate to take calculated risks at appropriate times.\n\n" +
                "* A person who is adventurous by nature may have higher courage and ability to take calculated risks.");

        sixteen.add("* An officer is often under physically and mentally demanding situations where he/she might have to withstand large physical/mental stress. Thus an officer must be physically and mentally tough to withstand stress.\n\n" +
                "* This is the ability of a candidate to stay strong under demanding situations.\n\n" +
                "* This is a highly flexible quality and highly trainable.");









        answer.put(question.get(0),one);
        answer.put(question.get(1),two);
        answer.put(question.get(2),three);
        answer.put(question.get(3),four);
        answer.put(question.get(4),five);
        answer.put(question.get(5),six);
        answer.put(question.get(6),seven);
        answer.put(question.get(7),eight);
        answer.put(question.get(8),nine);
        answer.put(question.get(9),ten);
        answer.put(question.get(10),eleven);
        answer.put(question.get(11),twelve);
        answer.put(question.get(12),thirteen);
        answer.put(question.get(13),forteen);
        answer.put(question.get(14),fifteen);
        answer.put(question.get(15),sixteen);






    }
}
