package com.example.ssbcrackpractice;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class fifth_day extends AppCompatActivity {
    ExpandableListView expandableListView;
    List<String> question;
    Map<String,List<String>> answer;
    ExpandableListAdapter listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifth_day);


        expandableListView = (ExpandableListView)findViewById(R.id.expandableListView);
        fillData();

        listAdapter=new MyexListadapter(this,question,answer);
        expandableListView.setAdapter(listAdapter);


        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {



                return true;
            }
        });



        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("CONFERENCE");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
    public void fillData()
    {
        question=new ArrayList<>();
        answer = new HashMap<>();

        question.add(" About Conference");
        question.add(" TIPS");
        question.add(" QUESTIONS ASKED");
        question.add(" HOW TO STAY CALM");

        List<String> one = new ArrayList<>();
        List<String> two= new ArrayList<>();
        List<String> three= new ArrayList<>();
        List<String> four= new ArrayList<>();



        one.add("* Conference Day is the last day of the 5 day SSB process. \n" +
                "\n" +
                "* This day officially declares the recommendation of candidate although it is a result of the performance of all five days of the candidate. \n" +
                "\n" +
                "* What happens on this day is that every candidate has to appear in  front of the whole Board in the Conference hall which generally has a large semi circular table and all officers sitting in their dresses around it.\n" +
                "\n" +
                "* The candidates are called in for conference one by one according to their chest numbers and the waiting period here is one of the most anxious moments of the SSB process.\n" +
                "\n" +
                "* Before calling a candidate in the conference  hall, there is generally a time gap `varying from 5-30 minutes and it is the time when the officers in the conference hall discuss about the result of the candidate. \n" +
                "\n" +
                "* Although , in most cases , the result has already been decided and candidate is called within 5 minutes, but sometimes if officers have a difference of opinion on a candidate , this may take long (up to half an hour). \n" +
                "\n" +
                "* when a candidate is called inside, he/she is asked to sit on a chair in front of the officers. \n" +
                "\n" +
                "* Although most of the times , general questions about food, stay, friends you made are asked but if a candidate is on the border line of recommendation,then one of the officers might throw some situations at you like you were given in the SRTs and your response to those situations might decide your result.\n");

        two.add("* Wear Clean and ironed clothes.\n" +
                "\n" +
                "* It is recommended to wash the Chest number the previous evening to wear a clean chest number on the Conference day.\n" +
                "\n" +
                "* Although the candidate will see a lot of officers in front of him/her on entering the conference hall, but wish only the one sitting in the middle and is the senior most officer of the board.\n" +
                "\n" +
                "* Prepare the answers for questions that you were not able to answer in the Personal Interview.\n" +
                "\n" +
                "* Do not get Nervous seeing so many officers in dress, try to stay calm by taking deep breaths.\n" +
                "\n" +
                "* Listen to Questions carefully.\n" +
                "\n" +
                "* Try not to complain about your stay until you gave a genuine and important concern.\n" +
                "\n" +
                "* Be clear and Loud.\n");


        three.add("* How was your stay?\n" +
                "\n" +
                "* Did you make friends here?\n" +
                "\n" +
                "* Did you face any problems? What were they?\n" +
                "\n" +
                "* How was the food?\n" +
                "\n" +
                "* What did you learn in the past five days? \n" +
                "\n" +
                "* Which places did you visit in these five days?\n" +
                "\n" +
                "* Rate your performance out of 10.\n" +
                "\n" +
                "* Who all from your group should get recommended?\n" +
                "\n" +
                "* Rank your performance in your group.\n" +
                "\n" +
                "* Who is the best candidate in your group?\n" +
                "\n" +
                "* How did you improve this time (repeaters) ?\n" +
                "\n" +
                "* Any suggestions for improvement in the SSB?\n");

        four.add("* This is the phase where candidates are the most nervous.\n" +
                "\n" +
                "* Although one must keep in mind that probably the result has been decided and there is no reason to worry.\n" +
                "\n" +
                "* Try to take deep breaths and think of positive things.\n" +
                "\n" +
                "* Have a  smile always.");










        answer.put(question.get(0),one);
        answer.put(question.get(1),two);
        answer.put(question.get(2),three);
        answer.put(question.get(3),four);




    }

}
