package com.example.ssbcrackpractice;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class about_ssb extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_ssb);

        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("About SSB");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    public void open_history(View view)
    {
        Intent intent=new Intent(about_ssb.this,History.class);
        startActivity(intent);
    }

    public void must_carry(View view)
    {
        Intent intent1=new Intent(about_ssb.this,Mustcarry.class);
        startActivity(intent1);
    }

    public void day_one(View view)
    {
        Intent intent2=new Intent(about_ssb.this,processday1.class);
        startActivity(intent2);
    }
    public void day_two(View view)
    {
        Intent intent2=new Intent(about_ssb.this,processday2.class);
        startActivity(intent2);
    }
    public void day_three(View view)
    {
        Intent intent2=new Intent(about_ssb.this,processday3.class);
        startActivity(intent2);
    }
    public void day_four(View view)
    {
        Intent intent2=new Intent(about_ssb.this,processday4.class);
        startActivity(intent2);
    }
    public void day_five(View view)
    {
        Intent intent2=new Intent(about_ssb.this,processday5.class);
        startActivity(intent2);
    }


    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
