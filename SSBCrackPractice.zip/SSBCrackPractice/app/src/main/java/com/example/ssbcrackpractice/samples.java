package com.example.ssbcrackpractice;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class samples extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_samples);


        ActionBar actionBar = getSupportActionBar();
        assert getSupportActionBar() != null;
        actionBar.setTitle("SAMPLE TESTS");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    public void goto_ppdt_process(View view)
    {
        Intent intent=new Intent(samples.this,ppdt_sample.class);
        startActivity(intent);
    }
    public void goto_ppdt_sample(View view)
    {
        Intent intent1=new Intent(samples.this,ppdt_realsample.class);
        startActivity(intent1);
    }
    public void goto_tat_sample(View view)
    {
        Intent intent2=new Intent(samples.this,tat_sample.class);
        startActivity(intent2);
    }
    public void goto_wat_sample(View view)
    {
        Intent intent3=new Intent(samples.this,wat_sample.class);
        startActivity(intent3);
    }
    public void goto_srt_sample(View view)
    {
        Intent intent4=new Intent(samples.this,srt_sample.class);
        startActivity(intent4);
    }

}
